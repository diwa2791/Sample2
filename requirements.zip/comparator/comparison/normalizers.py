"""Value normalisation.

Kubernetes and helm express the same quantity in several ways (2G, 2Gi, 2048Mi,
0.5 vs 500m CPU). Comparing raw strings would report drift that does not exist,
so quantities are converted to a canonical number before comparison.
"""

from __future__ import annotations

import re
from typing import Optional

_MEMORY_SUFFIXES = {
    "": 1,
    "k": 1000,
    "K": 1000,
    "M": 1000**2,
    "G": 1000**3,
    "T": 1000**4,
    "P": 1000**5,
    "Ki": 1024,
    "Mi": 1024**2,
    "Gi": 1024**3,
    "Ti": 1024**4,
    "Pi": 1024**5,
}

_QUANTITY_RE = re.compile(r"^\s*(?P<num>[0-9]*\.?[0-9]+)\s*(?P<suffix>[A-Za-z]*)\s*$")


def parse_memory(value: Optional[str]) -> Optional[int]:
    """Return bytes, or None when unparseable."""
    if value is None:
        return None
    match = _QUANTITY_RE.match(str(value))
    if not match:
        return None
    suffix = match.group("suffix")
    if suffix not in _MEMORY_SUFFIXES:
        return None
    return int(float(match.group("num")) * _MEMORY_SUFFIXES[suffix])


def parse_cpu(value: Optional[str]) -> Optional[int]:
    """Return millicores, or None when unparseable."""
    if value is None:
        return None
    match = _QUANTITY_RE.match(str(value))
    if not match:
        return None
    number = float(match.group("num"))
    suffix = match.group("suffix")
    if suffix == "m":
        return int(number)
    if suffix == "":
        return int(number * 1000)
    return None


def normalise_resource(key: str, value: Optional[str]) -> Optional[str]:
    """Canonical form for a dotted resource key, for comparison only.

    Falls back to the trimmed raw string when the value is not a quantity we
    understand, so unknown formats still compare as plain text.
    """
    if value is None:
        return None
    if key.endswith(".memory"):
        parsed = parse_memory(value)
        return str(parsed) if parsed is not None else str(value).strip()
    if key.endswith(".cpu"):
        parsed = parse_cpu(value)
        return str(parsed) if parsed is not None else str(value).strip()
    return str(value).strip()


def humanise_memory(num_bytes: Optional[int]) -> str:
    if num_bytes is None:
        return "-"
    for unit, factor in (("Gi", 1024**3), ("Mi", 1024**2), ("Ki", 1024)):
        if num_bytes >= factor:
            return f"{num_bytes / factor:.2f}".rstrip("0").rstrip(".") + unit
    return f"{num_bytes}B"
