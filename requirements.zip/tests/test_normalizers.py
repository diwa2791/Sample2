"""Quantity normalisation must not invent drift that does not exist."""

import pytest

from comparator.comparison.normalizers import (
    normalise_resource,
    parse_cpu,
    parse_memory,
)


@pytest.mark.parametrize(
    "value,expected",
    [
        ("2G", 2_000_000_000),
        ("2Gi", 2_147_483_648),
        ("256Mi", 268_435_456),
        ("1024Ki", 1_048_576),
        ("512", 512),
        ("bogus", None),
        (None, None),
    ],
)
def test_parse_memory(value, expected):
    assert parse_memory(value) == expected


@pytest.mark.parametrize(
    "value,expected",
    [("100m", 100), ("1", 1000), ("0.5", 500), ("2", 2000), ("junk", None)],
)
def test_parse_cpu(value, expected):
    assert parse_cpu(value) == expected


def test_equivalent_memory_forms_compare_equal():
    assert normalise_resource("limits.memory", "1Gi") == normalise_resource(
        "limits.memory", "1024Mi"
    )


def test_different_memory_forms_still_differ():
    assert normalise_resource("limits.memory", "2G") != normalise_resource(
        "limits.memory", "256Mi"
    )


def test_equivalent_cpu_forms_compare_equal():
    assert normalise_resource("requests.cpu", "1") == normalise_resource(
        "requests.cpu", "1000m"
    )


def test_unknown_format_falls_back_to_trimmed_string():
    assert normalise_resource("limits.memory", " weird ") == "weird"


def test_non_quantity_key_is_plain_string():
    assert normalise_resource("replicaCount", "3") == "3"
