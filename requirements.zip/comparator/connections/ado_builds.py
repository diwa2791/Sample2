"""Resolve an Azure DevOps pipeline run URL to the commit it was built from.

A CD run is only useful here for one thing: the commit of the helm repo it ran
against. Everything downstream then reads the chart *at that commit*, so
"compare build 8916368 with build 8976368" becomes an ordinary left/right
comparison of two points in the repo's history.

Needs a PAT with **Build (Read)** in addition to Code (Read).
"""

from __future__ import annotations

import base64
import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import requests

from comparator.config import Config
from comparator.connections.base import ConnectionError_

LOG = logging.getLogger(__name__)

# A full git sha, which is what Azure DevOps puts in sourceVersion.
SHA_RE = re.compile(r"^[0-9a-f]{40}$")


@dataclass
class BuildInfo:
    """The parts of a pipeline run this tool cares about."""

    id: str
    number: str
    commit: str
    branch: Optional[str] = None
    definition: Optional[str] = None
    repository: Optional[str] = None
    finished: Optional[str] = None
    result: Optional[str] = None
    url: Optional[str] = None

    @property
    def short_commit(self) -> str:
        return (self.commit or "")[:8]

    @property
    def label(self) -> str:
        """What the report column is called."""
        return f"Build {self.number}" if self.number else f"Build {self.id}"

    def describe(self) -> str:
        bits = [f"build {self.number or self.id}"]
        if self.definition:
            bits.append(self.definition)
        if self.branch:
            bits.append(self.branch)
        if self.commit:
            bits.append(self.short_commit)
        if self.finished:
            bits.append(self.finished[:10])
        return " · ".join(bits)


def parse_build_url(url: str) -> Tuple[str, str, str, str]:
    """Pull (base_url, organization, project, build_id) out of a run URL.

    Handles the two shapes Azure DevOps serves:
        https://dev.azure.com/{org}/{project}/_build/results?buildId=123
        https://{org}.visualstudio.com/{project}/_build/results?buildId=123
    and on-prem collections, where everything before the project is the base.
    """
    url = (url or "").strip()
    if not url:
        raise ValueError("No pipeline URL given.")

    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError(f"Not a URL: {url!r}")

    build_ids = parse_qs(parsed.query).get("buildId") or []
    if not build_ids or not build_ids[0].strip():
        raise ValueError(
            "No buildId in the URL. Expected a pipeline *run*, e.g. "
            ".../_build/results?buildId=456 — not a pipeline definition."
        )
    build_id = build_ids[0].strip()
    if not build_id.isdigit():
        raise ValueError(f"buildId is not a number: {build_id!r}")

    parts = [p for p in parsed.path.split("/") if p]
    if "_build" not in parts:
        raise ValueError(
            "URL does not look like a pipeline run (no /_build/ segment): " + url
        )
    prefix = parts[: parts.index("_build")]
    if not prefix:
        raise ValueError("Could not find the project in the URL: " + url)

    host = parsed.netloc
    root = f"{parsed.scheme}://{host}"
    if host.endswith(".visualstudio.com"):
        # org is the sub-domain; the path is just /{project}/...
        organization = host.split(".")[0]
        project = prefix[-1]
        base_url = root
    else:
        # dev.azure.com/{org}/{project}/... or on-prem /tfs/{collection}/{project}/...
        if len(prefix) < 2:
            raise ValueError(
                "Expected /{organization}/{project}/_build/... in the URL: " + url
            )
        project = prefix[-1]
        organization = prefix[-2]
        # Anything before org (e.g. /tfs) belongs to the server root.
        extra = prefix[:-2]
        base_url = root + ("/" + "/".join(extra) if extra else "")

    return base_url, organization, project, build_id


class AdoBuildClient:
    """Read-only access to the Build API."""

    def __init__(
        self,
        pat: str,
        api_version: str = "7.1",
        timeout_seconds: int = 30,
        verify_ssl: bool = True,
    ) -> None:
        if not pat:
            raise ConnectionError_(
                "Azure DevOps PAT is empty. Build2Build reads the pipeline API, so "
                "set ADO_PAT (scopes: Build (Read) and Code (Read))."
            )
        self.api_version = api_version
        self.timeout = timeout_seconds
        self._session = requests.Session()
        self._session.verify = verify_ssl
        token = base64.b64encode(f":{pat}".encode()).decode()
        self._session.headers.update(
            {"Authorization": f"Basic {token}", "Accept": "application/json"}
        )

    def get_build(self, url: str) -> BuildInfo:
        """Resolve a run URL to its build, including the commit it ran on."""
        base_url, organization, project, build_id = parse_build_url(url)
        api = f"{base_url}/{organization}/{project}/_apis/build/builds/{build_id}"
        try:
            resp = self._session.get(
                api, params={"api-version": self.api_version}, timeout=self.timeout
            )
        except requests.RequestException as exc:
            raise ConnectionError_(f"Could not reach Azure DevOps: {exc}") from exc

        if resp.status_code == 404:
            raise ConnectionError_(
                f"Build {build_id} not found in {organization}/{project}."
            )
        if resp.status_code in (401, 203):
            raise ConnectionError_(
                "Azure DevOps rejected the PAT for the Build API (401/203). "
                "Build2Build needs the Build (Read) scope, not just Code (Read)."
            )
        if not resp.ok:
            raise ConnectionError_(
                f"Build API returned {resp.status_code} for build {build_id}: "
                f"{resp.text[:200]}"
            )
        try:
            data: Dict[str, Any] = resp.json()
        except ValueError as exc:
            raise ConnectionError_(
                f"Build API did not return JSON for build {build_id}."
            ) from exc

        commit = (data.get("sourceVersion") or "").strip()
        if not commit:
            raise ConnectionError_(
                f"Build {build_id} has no sourceVersion, so there is no commit to "
                "compare against."
            )

        repo = data.get("repository") or {}
        branch = data.get("sourceBranch") or None
        if branch and branch.startswith("refs/heads/"):
            branch = branch[len("refs/heads/") :]

        return BuildInfo(
            id=str(data.get("id") or build_id),
            number=str(data.get("buildNumber") or ""),
            commit=commit,
            branch=branch,
            definition=(data.get("definition") or {}).get("name"),
            repository=repo.get("name"),
            finished=data.get("finishTime"),
            result=data.get("result"),
            url=url,
        )

    @classmethod
    def from_config(cls, config: Config) -> "AdoBuildClient":
        section = config.section("connections.azure_devops")
        return cls(
            pat=section.get("pat", ""),
            api_version=str(section.get("api_version", "7.1")),
            timeout_seconds=int(section.get("timeout_seconds", 30)),
            verify_ssl=bool(section.get("verify_ssl", True)),
        )
