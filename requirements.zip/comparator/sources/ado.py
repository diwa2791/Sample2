"""Build snapshots from the helm values held in Azure DevOps.

Reads three things per service:
  images file    -> imagePath + version(@digest)
  service file   -> replicaCount, resources, serviceProperties
  common file    -> commonProperties merged underneath serviceProperties

Services may be split across several branches (branch1 owns 50, branch2 owns
50, branch3 owns 40 ...). A service lives on exactly one branch, so each one
must first be *resolved* to its branch. Resolution order:

  1. an explicit pin in config (target.service_branches)
  2. the branch whose images file lists the service -- one read per branch,
     not per service, which matters at 140 services
  3. probing for the service file on each branch in turn

The values file is the authority: a hint from the images file is confirmed
against it, and a service found on more than one branch is reported rather
than silently resolved.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Set, Tuple

from comparator.config import Config
from comparator.connections.azure_devops import version_type
from comparator.connections.base import ConnectionError_, RepoConnection
from comparator.models import ImageSpec, ResourceSpec, ServiceSnapshot, Side
from comparator.utils.yaml_utils import (
    dig,
    extract_block,
    parse_properties,
    safe_load_lenient,
)

LOG = logging.getLogger(__name__)


class AdoSource:
    """Reads declared state from the helm chart repo."""

    side = Side.LEFT

    def __init__(
        self,
        connection: RepoConnection,
        config: Config,
        cluster: Optional[str] = None,
        env: Optional[str] = None,
        ref: Optional[str] = None,
    ) -> None:
        """Two overrides, for the two comparisons built on this source:

        `cluster`/`env` point an instance at a different folder of the chart
        (folder-vs-folder), and `ref` pins it to one branch or commit
        (build-vs-build). A pinned ref skips branch discovery entirely --
        a commit already says exactly which tree to read.
        """
        self.conn = connection
        self.cfg = config
        layout = config.section("repo_layout")
        self.images_tpl = layout.get("images_file", "")
        self.service_tpl = layout.get("service_file", "")
        self.common_tpl = layout.get("common_file", "")
        self.images_root = layout.get("images_root_key", "images")
        self.micro_root = layout.get("microservices_root_key", "microservices")
        self.props_key = layout.get("service_properties_key", "serviceProperties")
        self.common_props_key = layout.get("common_properties_key", "commonProperties")
        self.cluster = cluster or config.get("target.cluster", "")
        self.env = env or config.get("target.env", "")
        self.include_common = bool(
            config.get("comparison.configmap.include_common", True)
        )
        self.registry = config.get("comparison.image.registry") or None
        self.pins: Dict[str, str] = dict(config.get("target.service_branches") or {})
        self.ref = ref
        # One pinned ref collapses branch resolution to the single-ref path.
        self.branches: List[str] = [ref] if ref else list(connection.refs)
        # Files are read once per (path, branch) per run, not once per service.
        self._file_cache: Dict[Tuple[str, str], Tuple[Optional[str], Optional[str]]] = {}
        self._index: Optional[Dict[str, Set[str]]] = None
        self._resolved: Dict[str, Tuple[Optional[str], List[str]]] = {}

    # -- file access ------------------------------------------------------

    def _path(self, template: str, service: str = "") -> str:
        return template.format(cluster=self.cluster, env=self.env, service=service)

    def _read(self, path: str, branch: str) -> Tuple[Optional[str], Optional[str]]:
        """Return (text, error). Cached per (path, branch)."""
        key = (path, branch)
        if key in self._file_cache:
            return self._file_cache[key]
        try:
            result: Tuple[Optional[str], Optional[str]] = (
                self.conn.read_text(path, branch),
                None,
            )
        except FileNotFoundError as exc:
            result = (None, str(exc))
        except ConnectionError_ as exc:
            result = (None, str(exc))
        self._file_cache[key] = result
        return result

    # -- branch resolution ------------------------------------------------

    def _images_data(self, branch: str) -> Tuple[Dict[str, Any], List[str]]:
        path = self._path(self.images_tpl)
        text, err = self._read(path, branch)
        if text is None:
            return {}, [f"images file unavailable on {branch} ({err})"]
        return safe_load_lenient(text)

    def _images_index(self) -> Dict[str, Set[str]]:
        """branch -> services its images file declares. Built once per run."""
        if self._index is not None:
            return self._index
        index: Dict[str, Set[str]] = {}
        for branch in self.branches:
            data, _ = self._images_data(branch)
            entries = dig(data, self.images_root)
            index[branch] = set(entries) if isinstance(entries, dict) else set()
            LOG.debug("branch %s declares %d image(s)", branch, len(index[branch]))
        self._index = index
        return index

    def list_services(self) -> List[str]:
        """Every service declared by any branch's images file."""
        return sorted({s for names in self._images_index().values() for s in names})

    def _candidates(self, service: str) -> List[str]:
        """Branches to try, most likely first."""
        if len(self.branches) == 1:
            return list(self.branches)
        index = self._images_index()
        hinted = [b for b in self.branches if service in index.get(b, ())]
        rest = [b for b in self.branches if b not in hinted]
        return hinted + rest

    def _resolve_branch(self, service: str) -> Tuple[Optional[str], List[str]]:
        """Find the branch holding this service's values file."""
        if service in self._resolved:
            return self._resolved[service]

        issues: List[str] = []
        # A pinned ref (a build's commit) is the whole point of that run --
        # a per-service branch pin must not drag us onto another tree.
        pinned = None if self.ref else self.pins.get(service)
        if pinned:
            if pinned not in self.branches:
                issues.append(
                    f"pinned to branch {pinned!r}, which is not in the configured branches"
                )
            result = (pinned, issues)
            self._resolved[service] = result
            return result

        # The path is branch-independent; only the ref we read it from varies.
        path = self._path(self.service_tpl, service)

        if len(self.branches) == 1:
            branch = self.branches[0]
            found = [branch] if self._read(path, branch)[0] is not None else []
        else:
            hinted = [b for b in self.branches if service in self._images_index().get(b, ())]
            if len(hinted) > 1:
                issues.append(
                    "declared in the images file of several branches ({})".format(
                        ", ".join(hinted)
                    )
                )
            if len(hinted) == 1 and self._read(path, hinted[0])[0] is not None:
                # Fast path: one branch claims it and the values file is there.
                # Stop -- probing the rest would cost a request per branch per
                # service, which is the whole reason the index exists.
                found = hinted
            else:
                if len(hinted) == 1:
                    issues.append(
                        f"images file on {hinted[0]} declares this service but no "
                        f"values file is there; searched every branch"
                    )
                found = [
                    b for b in self._candidates(service) if self._read(path, b)[0] is not None
                ]
                if len(found) > 1:
                    # Real signal, not noise: the same service defined on two
                    # branches means whichever deploys last wins.
                    issues.append(
                        "values file exists on multiple branches ({}); using {}".format(
                            ", ".join(found), found[0]
                        )
                    )
                elif found and not hinted:
                    issues.append(
                        f"no images file declares this service; resolved to "
                        f"{found[0]} by its values file"
                    )

        self._resolved[service] = (found[0] if found else None, issues)
        return self._resolved[service]

    # -- parsing ----------------------------------------------------------

    def _common_properties(self, branch: str) -> Tuple[Dict[str, str], List[str]]:
        if not self.include_common or not self.common_tpl:
            return {}, []
        path = self._path(self.common_tpl)
        text, err = self._read(path, branch)
        if text is None:
            return {}, [f"common file unavailable ({err})"]

        # Lift the block out before YAML parsing so the repair pass can never
        # rewrite property text (the rest of the file needs repairing; the
        # block does not).
        leaf = self.common_props_key.rsplit(".", 1)[-1]
        remaining, block = extract_block(text, leaf)
        if block is not None:
            _, issues = safe_load_lenient(remaining)
            return parse_properties(block), issues

        data, issues = safe_load_lenient(text)
        found = dig(data, self.common_props_key)
        if not isinstance(found, str):
            return {}, issues
        return parse_properties(found), issues

    def _image(self, service: str, branch: str) -> Tuple[ImageSpec, List[str], Optional[str]]:
        path = self._path(self.images_tpl)
        data, issues = self._images_data(branch)
        entry = dig(data, f"{self.images_root}.{service}")
        if not isinstance(entry, dict):
            issues.append(f"no image entry for {service} under {self.images_root}")
            return ImageSpec(), issues, self.conn.describe(path, branch)

        version = str(entry.get("version") or "")
        tag, digest = _split_version(version)
        spec = ImageSpec(
            registry=self.registry,
            path=str(entry.get("imagePath") or "") or None,
            tag=tag,
            digest=digest,
        )
        return spec, issues, self.conn.describe(path, branch)

    def _service_file(
        self, service: str, branch: str
    ) -> Tuple[Dict[str, Any], Dict[str, str], List[str], Optional[str], bool]:
        path = self._path(self.service_tpl, service)
        text, err = self._read(path, branch)
        if text is None:
            return {}, {}, [f"service file unavailable ({err})"], None, False

        # Pull the properties block out before YAML sees it -- it is not a
        # valid block scalar in these files.
        remaining, block = extract_block(text, self.props_key)
        props = parse_properties(block) if block else {}

        data, issues = safe_load_lenient(remaining)
        node = dig(data, f"{self.micro_root}.{service}")
        if not isinstance(node, dict):
            issues.append(f"no entry for {service} under {self.micro_root}")
            node = {}
        if block is None:
            issues.append(f"no '{self.props_key}' block found")
        return node, props, issues, self.conn.describe(path, branch), True

    # -- public -----------------------------------------------------------

    def snapshot(self, service: str) -> ServiceSnapshot:
        snap = ServiceSnapshot(name=service, side=Side.LEFT)

        branch, issues = self._resolve_branch(service)
        snap.issues.extend(issues)
        if branch is None:
            snap.found = False
            snap.issues.append(
                "no values file on any configured branch ({})".format(
                    ", ".join(self.branches)
                )
            )
            return snap

        # A commit is not a branch: recording it as one would put a sha in the
        # report's branch chip and have it counted as a branch in the summary.
        if version_type(branch) == "commit":
            snap.origin["commit"] = branch
        else:
            snap.origin["branch"] = branch

        node, props, file_issues, origin, found = self._service_file(service, branch)
        snap.issues.extend(file_issues)
        snap.found = found
        if origin:
            snap.origin["service_file"] = origin

        common, common_issues = self._common_properties(branch)
        snap.issues.extend(common_issues)
        # Service properties win over common.
        merged = dict(common)
        merged.update(props)
        snap.config = merged

        image, image_issues, image_origin = self._image(service, branch)
        snap.issues.extend(image_issues)
        snap.image = image
        if image_origin:
            snap.origin["images_file"] = image_origin

        snap.resources = ResourceSpec(_resources_from_node(node))
        return snap


def _split_version(version: str) -> Tuple[Optional[str], Optional[str]]:
    """`8916368@sha256:abc` -> ('8916368', 'sha256:abc')."""
    if not version:
        return None, None
    if "@" in version:
        tag, _, digest = version.partition("@")
        return (tag or None), (digest or None)
    return version, None


def _resources_from_node(node: Dict[str, Any]) -> Dict[str, Optional[str]]:
    """Flatten helm resource config into the dotted keys the engine compares."""
    resources = node.get("resources") if isinstance(node, dict) else {}
    resources = resources if isinstance(resources, dict) else {}
    requests = resources.get("requests") or {}
    limits = resources.get("limits") or {}
    requests = requests if isinstance(requests, dict) else {}
    limits = limits if isinstance(limits, dict) else {}

    def as_str(value: Any) -> Optional[str]:
        return None if value is None else str(value)

    return {
        "requests.memory": as_str(requests.get("memory")),
        "requests.cpu": as_str(requests.get("cpu")),
        "limits.memory": as_str(limits.get("memory")),
        "limits.cpu": as_str(limits.get("cpu")),
        "replicaCount": as_str(node.get("replicaCount")),
    }
