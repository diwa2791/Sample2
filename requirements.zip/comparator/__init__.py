"""Compare declared helm values in Azure DevOps against live Kubernetes state."""

__version__ = "0.1.0"
