"""The config editor must never cost the file its comments or placeholders."""

import yaml

from comparator.webui.yaml_edit import (
    apply_changes,
    dig_raw,
    find_key,
    format_scalar,
    load_raw,
)

SAMPLE = """\
# Top comment
connections:
  azure_devops:
    # which mode to use
    mode: ${ADO_MODE:local}
    organization: my-org
    timeout_seconds: 30
    verify_ssl: true
    branch_roots: {}

  kubernetes:
    # empty means current context
    mode: kubeconfig
    context: ${K8S_CONTEXT:}
    namespace: devilsworld

target:
  cluster: ske
  # the services to compare
  services:
    - aa-amazon-owd01
    - aa-flip-owd01
  service_branches: {}

report:
  title: "Helm vs Kubernetes Drift Report"
  fail_on_mismatch: false
"""


def test_comments_survive_an_edit():
    out = apply_changes(SAMPLE, [("scalar", "target.cluster", "prd")])
    assert "# Top comment" in out
    assert "# which mode to use" in out
    assert "# the services to compare" in out
    assert "# empty means current context" in out
    assert "cluster: prd" in out


def test_untouched_lines_are_byte_identical():
    out = apply_changes(SAMPLE, [("scalar", "target.cluster", "prd")])
    before = [l for l in SAMPLE.splitlines() if "cluster:" not in l]
    after = [l for l in out.splitlines() if "cluster:" not in l]
    assert before == after


def test_env_placeholders_on_other_keys_are_not_resolved():
    out = apply_changes(SAMPLE, [("scalar", "target.cluster", "prd")])
    # The whole point: a load/dump round-trip would have replaced these with
    # whatever the environment held.
    assert "mode: ${ADO_MODE:local}" in out
    assert "context: ${K8S_CONTEXT:}" in out


def test_can_set_a_placeholder_as_a_value():
    out = apply_changes(SAMPLE, [("scalar", "connections.kubernetes.context", "${K8S_CONTEXT:minikube}")])
    assert "context: ${K8S_CONTEXT:minikube}" in out
    assert yaml.safe_load(out)["connections"]["kubernetes"]["context"] == "${K8S_CONTEXT:minikube}"


def test_nested_paths_disambiguate_duplicate_keys():
    # `mode` exists under both azure_devops and kubernetes.
    out = apply_changes(SAMPLE, [("scalar", "connections.kubernetes.mode", "in_cluster")])
    data = load_raw(out)
    assert data["connections"]["kubernetes"]["mode"] == "in_cluster"
    assert data["connections"]["azure_devops"]["mode"] == "${ADO_MODE:local}"


def test_booleans_and_numbers_stay_typed():
    out = apply_changes(
        SAMPLE,
        [
            ("scalar", "connections.azure_devops.verify_ssl", False),
            ("scalar", "connections.azure_devops.timeout_seconds", 60),
            ("scalar", "report.fail_on_mismatch", True),
        ],
    )
    data = load_raw(out)
    assert data["connections"]["azure_devops"]["verify_ssl"] is False
    assert data["connections"]["azure_devops"]["timeout_seconds"] == 60
    assert data["report"]["fail_on_mismatch"] is True


def test_replace_list_contents():
    out = apply_changes(SAMPLE, [("list", "target.services", ["a", "b", "c"])])
    assert load_raw(out)["target"]["services"] == ["a", "b", "c"]
    assert "# the services to compare" in out


def test_shrinking_a_list_removes_the_old_items():
    out = apply_changes(SAMPLE, [("list", "target.services", ["only-one"])])
    assert load_raw(out)["target"]["services"] == ["only-one"]
    assert "aa-flip-owd01" not in out


def test_empty_list_round_trips_as_empty():
    out = apply_changes(SAMPLE, [("list", "target.services", [])])
    assert load_raw(out)["target"]["services"] == []


def test_map_from_empty_to_populated_and_back():
    out = apply_changes(SAMPLE, [("map", "target.service_branches", {"svc-a": "branch2"})])
    assert load_raw(out)["target"]["service_branches"] == {"svc-a": "branch2"}
    # and back to empty
    out2 = apply_changes(out, [("map", "target.service_branches", {})])
    assert load_raw(out2)["target"]["service_branches"] == {}
    assert "svc-a" not in out2


def test_setting_a_map_does_not_swallow_the_next_section():
    out = apply_changes(SAMPLE, [("map", "target.service_branches", {"x": "y"})])
    data = load_raw(out)
    assert "report" in data
    assert data["report"]["title"] == "Helm vs Kubernetes Drift Report"


def test_list_edit_does_not_swallow_following_keys():
    out = apply_changes(SAMPLE, [("list", "target.services", ["a"])])
    data = load_raw(out)
    assert "service_branches" in data["target"]
    assert data["report"]["fail_on_mismatch"] is False


def test_values_needing_quotes_are_quoted():
    out = apply_changes(SAMPLE, [("scalar", "report.title", "a: b # c")])
    assert load_raw(out)["report"]["title"] == "a: b # c"


def test_empty_string_is_preserved_as_empty_not_none():
    out = apply_changes(SAMPLE, [("scalar", "connections.kubernetes.context", "")])
    assert load_raw(out)["connections"]["kubernetes"]["context"] == ""


def test_result_is_always_valid_yaml():
    out = apply_changes(
        SAMPLE,
        [
            ("scalar", "target.cluster", "prd"),
            ("list", "target.services", ["x", "y"]),
            ("map", "target.service_branches", {"x": "b1"}),
            ("scalar", "report.title", "New: Title"),
        ],
    )
    yaml.safe_load(out)  # must not raise


def test_unknown_path_is_rejected_rather_than_invented():
    try:
        apply_changes(SAMPLE, [("scalar", "target.nope", "x")])
    except KeyError as exc:
        assert "not present" in str(exc)
    else:
        raise AssertionError("should have raised")


def test_find_key_returns_none_for_missing():
    assert find_key(SAMPLE.splitlines(), "no.such.path") is None


def test_dig_raw():
    data = load_raw(SAMPLE)
    assert dig_raw(data, "connections.kubernetes.namespace") == "devilsworld"
    assert dig_raw(data, "a.b.c", "fallback") == "fallback"


def test_format_scalar_shapes():
    assert format_scalar(True) == "true"
    assert format_scalar(3) == "3"
    assert format_scalar("plain") == "plain"
    assert format_scalar("${A:b}") == "${A:b}"
    assert format_scalar("") == '""'
    assert format_scalar("has: colon").startswith('"')
