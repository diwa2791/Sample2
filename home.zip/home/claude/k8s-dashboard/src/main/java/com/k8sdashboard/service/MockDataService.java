package com.k8sdashboard.service;

import com.k8sdashboard.model.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Mock data service simulating a real K8s cluster with ~140 services.
 * Uses lazy generation + caching to avoid memory bloat.
 */
@Service
public class MockDataService {

    // Lazily generated, cached in memory. ConcurrentHashMap for thread safety.
    private final Map<String, List<Pod>> podCache = new ConcurrentHashMap<>();
    private final Map<String, Deployment> deploymentCache = new ConcurrentHashMap<>();
    private final Map<String, ConfigMap> configMapCache = new ConcurrentHashMap<>();
    private final Map<String, Integer> replicaOverrides = new ConcurrentHashMap<>();
    private final List<Backup> backups = Collections.synchronizedList(new ArrayList<>());

    private static final String[] NAMESPACES = {"default", "payments", "auth", "catalog", "orders", "infra", "monitoring"};
    private static final String[] SERVICE_NAMES = {
        "api-gateway", "user-service", "auth-service", "payment-service", "order-service",
        "catalog-service", "inventory-service", "notification-service", "email-service",
        "search-service", "recommendation-service", "cart-service", "checkout-service",
        "pricing-service", "discount-service", "loyalty-service", "review-service",
        "shipping-service", "tracking-service", "returns-service", "fraud-detection",
        "analytics-service", "reporting-service", "export-service", "import-service",
        "media-service", "cdn-proxy", "image-processor", "video-service", "document-service",
        "config-service", "feature-flags", "ab-testing", "experiment-service",
        "audit-service", "logging-service", "metrics-aggregator", "alerting-service",
        "webhook-service", "event-bus", "message-broker-proxy", "stream-processor",
        "batch-processor", "scheduler-service", "cron-manager", "task-queue",
        "cache-service", "session-service", "token-service", "oauth-service",
        "sso-proxy", "ldap-bridge", "identity-service", "permission-service",
        "role-manager", "policy-engine", "rate-limiter", "circuit-breaker-proxy",
        "load-balancer-api", "health-checker", "status-page", "maintenance-service",
        "backup-service", "restore-service", "migration-runner", "seed-service",
        "data-sync", "etl-service", "data-pipeline", "ml-inference", "model-server",
        "prediction-service", "scoring-service", "training-scheduler",
        "customer-service", "support-ticket", "chat-service", "live-agent",
        "bot-service", "nlp-service", "translation-service", "localization-service",
        "currency-service", "tax-service", "invoice-service", "billing-service",
        "subscription-service", "plan-service", "quota-service", "usage-tracker",
        "account-service", "profile-service", "address-service", "contact-service",
        "social-auth", "oauth2-provider", "jwt-validator", "api-key-manager",
        "webhook-receiver", "callback-service", "redirect-service", "url-shortener",
        "geo-service", "timezone-service", "calendar-service", "reminder-service",
        "push-notification", "sms-service", "voice-service", "video-call",
        "file-storage", "object-store-proxy", "archive-service", "compression-service",
        "encryption-service", "signing-service", "certificate-manager", "vault-proxy",
        "secrets-rotator", "key-manager", "hsm-bridge", "compliance-checker",
        "gdpr-service", "consent-manager", "data-retention", "purge-service",
        "partner-api", "vendor-connector", "erp-bridge", "crm-sync",
        "marketplace-service", "affiliate-service", "referral-service", "campaign-service",
        "seo-service", "sitemap-service", "feed-service", "scraper-service",
        "monitoring-agent", "log-forwarder", "trace-collector", "profiler-service",
        "chaos-monkey", "canary-manager", "rollout-controller", "deployment-tracker"
    };

    private static final Random RNG = new Random(42); // seeded for reproducibility

    // ─────────────────────────────────────────────
    //  PODS
    // ─────────────────────────────────────────────

    public List<Pod> getPodsForEnv(String env) {
        return podCache.computeIfAbsent(env, this::generatePods);
    }

    public List<Pod> getPodsByStatus(String env, String status) {
        return getPodsForEnv(env).stream()
                .filter(p -> p.getStatus().equals(status))
                .collect(Collectors.toList());
    }

    public Optional<Pod> getPodByName(String env, String name) {
        return getPodsForEnv(env).stream()
                .filter(p -> p.getName().equals(name))
                .findFirst();
    }

    private List<Pod> generatePods(String env) {
        List<Pod> pods = new ArrayList<>();
        boolean isPrd = "PRD".equalsIgnoreCase(env);

        for (int i = 0; i < SERVICE_NAMES.length; i++) {
            String svc = SERVICE_NAMES[i];
            String ns = NAMESPACES[i % NAMESPACES.length];
            int replicas = isPrd ? (2 + RNG.nextInt(4)) : (1 + RNG.nextInt(2));
            replicas = replicaOverrides.getOrDefault(svc, replicas);

            // Assign statuses: in DEV, ~70% running, ~15% failed, ~15% crashloop
            // In PRD, ~90% running, ~5% failed, ~5% crashloop
            for (int r = 0; r < replicas; r++) {
                String status = pickStatus(isPrd, i, r);
                pods.add(Pod.builder()
                        .name(svc + "-" + randomHash())
                        .namespace(ns)
                        .status(status)
                        .deploymentName(svc)
                        .image("registry.company.io/" + svc)
                        .restartCount(status.equals("RUNNING") ? RNG.nextInt(3) : 5 + RNG.nextInt(20))
                        .node("node-" + (1 + RNG.nextInt(isPrd ? 10 : 5)))
                        .podIp("10." + (1 + RNG.nextInt(5)) + "." + RNG.nextInt(255) + "." + (1 + RNG.nextInt(254)))
                        .cpuMillicores(50 + RNG.nextInt(400))
                        .memoryMi(64 + RNG.nextInt(512))
                        .cpuLimitMillicores(500)
                        .memoryLimitMi(512)
                        .startTime(LocalDateTime.now().minusHours(RNG.nextInt(720)))
                        .readyContainers(status.equals("RUNNING") ? 1 : 0)
                        .totalContainers(1)
                        .reason(status.equals("RUNNING") ? null : pickReason(status))
                        .labels(Map.of("app", svc, "env", env.toLowerCase()))
                        .build());
            }
        }
        return pods;
    }

    private String pickStatus(boolean isPrd, int serviceIdx, int replicaIdx) {
        int r = RNG.nextInt(100);
        if (isPrd) {
            if (r < 90) return "RUNNING";
            if (r < 95) return "FAILED";
            return "CRASH_LOOP";
        } else {
            if (r < 70) return "RUNNING";
            if (r < 85) return "FAILED";
            return "CRASH_LOOP";
        }
    }

    private String pickReason(String status) {
        String[] failedReasons = {"OOMKilled", "Error", "ContainerCannotRun", "DeadlineExceeded"};
        String[] crashReasons = {"CrashLoopBackOff", "RunContainerError", "ImagePullBackOff"};
        if ("FAILED".equals(status)) return failedReasons[RNG.nextInt(failedReasons.length)];
        return crashReasons[RNG.nextInt(crashReasons.length)];
    }

    private String randomHash() {
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) sb.append(chars.charAt(RNG.nextInt(chars.length())));
        sb.append("-");
        for (int i = 0; i < 5; i++) sb.append(chars.charAt(RNG.nextInt(chars.length())));
        return sb.toString();
    }

    // ─────────────────────────────────────────────
    //  SCALE
    // ─────────────────────────────────────────────

    public void scaleDeployment(String env, String deploymentName, int replicas) {
        replicaOverrides.put(deploymentName, replicas);
        podCache.remove(env); // invalidate cache
    }

    // ─────────────────────────────────────────────
    //  DEPLOYMENTS
    // ─────────────────────────────────────────────

    public Deployment getDeployment(String env, String name) {
        return deploymentCache.computeIfAbsent(env + "/" + name, k -> generateDeployment(name, env));
    }

    public void updateDeployment(String env, String name, Deployment updated) {
        deploymentCache.put(env + "/" + name, updated);
        podCache.remove(env);
    }

    private Deployment generateDeployment(String name, String env) {
        String[] tags = {"1.0.2", "1.1.0", "2.0.0", "2.3.1", "3.0.0-rc1", "latest", "stable"};
        return Deployment.builder()
                .name(name)
                .namespace(NAMESPACES[Math.abs(name.hashCode()) % NAMESPACES.length])
                .replicas(replicaOverrides.getOrDefault(name, "PRD".equals(env) ? 3 : 1))
                .availableReplicas("PRD".equals(env) ? 3 : 1)
                .readyReplicas("PRD".equals(env) ? 3 : 1)
                .image("registry.company.io/" + name)
                .imageTag(tags[Math.abs(name.hashCode()) % tags.length])
                .strategy("RollingUpdate")
                .resources(Deployment.ResourceConfig.builder()
                        .cpuRequest("100m").cpuLimit("500m")
                        .memoryRequest("128Mi").memoryLimit("512Mi")
                        .build())
                .envVars(Map.of(
                        "SPRING_PROFILES_ACTIVE", env.toLowerCase(),
                        "LOG_LEVEL", "INFO",
                        "DB_POOL_SIZE", "10"
                ))
                .labels(Map.of("app", name, "env", env.toLowerCase()))
                .build();
    }

    // ─────────────────────────────────────────────
    //  CONFIGMAPS
    // ─────────────────────────────────────────────

    public ConfigMap getConfigMap(String env, String name) {
        return configMapCache.computeIfAbsent(env + "/" + name, k -> generateConfigMap(name, env));
    }

    public void updateConfigMap(String env, String name, Map<String, String> data) {
        ConfigMap cm = getConfigMap(env, name);
        cm.setData(new LinkedHashMap<>(data));
        configMapCache.put(env + "/" + name, cm);
    }

    private ConfigMap generateConfigMap(String name, String env) {
        return ConfigMap.builder()
                .name(name + "-config")
                .namespace(NAMESPACES[Math.abs(name.hashCode()) % NAMESPACES.length])
                .data(new LinkedHashMap<>(Map.of(
                        "app.name", name,
                        "app.env", env.toLowerCase(),
                        "app.log-level", "INFO",
                        "app.timeout", "30000",
                        "app.retry-count", "3",
                        "app.feature-flag-enabled", "true",
                        "app.max-connections", "100"
                )))
                .createdAt("2024-01-15T10:00:00Z")
                .build();
    }

    // ─────────────────────────────────────────────
    //  LOGS
    // ─────────────────────────────────────────────

    public String generateLogs(String podName, int lines) {
        String[] levels = {"INFO", "INFO", "INFO", "WARN", "ERROR", "DEBUG"};
        String[] components = {"o.s.web.servlet.DispatcherServlet", "c.k8s.service.RequestHandler",
                "c.k8s.service.DatabaseConnector", "c.k8s.service.CacheManager", "o.h.e.jdbc.spi.SqlExceptionHelper"};
        String[] messages = {
                "Request processed successfully in 45ms",
                "Starting service initialization",
                "Connected to database pool (active: 5/10)",
                "Cache hit ratio: 87%",
                "Slow query detected: SELECT * FROM orders (1250ms)",
                "Connection pool exhausted, waiting for available connection",
                "Health check passed",
                "Processing message from queue: event-bus",
                "Retry attempt 2/3 for downstream service",
                "Circuit breaker OPEN for payment-service"
        };

        StringBuilder sb = new StringBuilder();
        LocalDateTime base = LocalDateTime.now().minusMinutes(lines);
        for (int i = 0; i < lines; i++) {
            LocalDateTime ts = base.plusMinutes(i);
            String level = levels[RNG.nextInt(levels.length)];
            String comp = components[RNG.nextInt(components.length)];
            String msg = messages[RNG.nextInt(messages.length)];
            sb.append(String.format("%s  %-5s %s --- [main] %-45s : %s%n",
                    ts, level, podName.substring(0, Math.min(8, podName.length())), comp, msg));
        }
        return sb.toString();
    }

    // ─────────────────────────────────────────────
    //  BACKUPS
    // ─────────────────────────────────────────────

    public Backup createBackup(String env) {
        List<Pod> pods = getPodsForEnv(env);
        Set<String> seen = new HashSet<>();
        List<Backup.BackupEntry> entries = new ArrayList<>();

        for (Pod pod : pods) {
            if (seen.add(pod.getDeploymentName())) {
                Deployment dep = getDeployment(env, pod.getDeploymentName());
                ConfigMap cm = getConfigMap(env, pod.getDeploymentName());
                entries.add(Backup.BackupEntry.builder()
                        .serviceName(pod.getDeploymentName())
                        .namespace(pod.getNamespace())
                        .replicaCount(dep.getReplicas())
                        .image(dep.getImage())
                        .imageTag(dep.getImageTag())
                        .configMapData(new LinkedHashMap<>(cm.getData()))
                        .cpuRequest(dep.getResources().getCpuRequest())
                        .cpuLimit(dep.getResources().getCpuLimit())
                        .memoryRequest(dep.getResources().getMemoryRequest())
                        .memoryLimit(dep.getResources().getMemoryLimit())
                        .build());
            }
        }

        Backup backup = Backup.builder()
                .id(UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .environment(env)
                .createdAt(LocalDateTime.now())
                .createdBy("dashboard-user")
                .status(Backup.BackupStatus.COMPLETED)
                .entries(entries)
                .notes("Snapshot of " + entries.size() + " services")
                .build();

        backups.add(0, backup);
        if (backups.size() > 20) backups.subList(20, backups.size()).clear(); // cap history
        return backup;
    }

    public List<Backup> getBackups(String env) {
        return backups.stream()
                .filter(b -> b.getEnvironment().equalsIgnoreCase(env))
                .collect(Collectors.toList());
    }

    public Optional<Backup> getBackupById(String id) {
        return backups.stream().filter(b -> b.getId().equals(id)).findFirst();
    }

    // ─────────────────────────────────────────────
    //  DIFF (PRD)
    // ─────────────────────────────────────────────

    public List<DiffResult> compareBackupWithCurrent(String backupId) {
        return getBackupById(backupId).map(backup -> {
            List<DiffResult> results = new ArrayList<>();
            for (Backup.BackupEntry entry : backup.getEntries()) {
                Deployment current = getDeployment(backup.getEnvironment(), entry.getServiceName());
                ConfigMap currentCm = getConfigMap(backup.getEnvironment(), entry.getServiceName());

                List<DiffResult.DiffEntry> diffs = new ArrayList<>();

                // Compare replicas
                if (current.getReplicas() != entry.getReplicaCount()) {
                    diffs.add(DiffResult.DiffEntry.builder()
                            .field("replicas")
                            .backupValue(String.valueOf(entry.getReplicaCount()))
                            .currentValue(String.valueOf(current.getReplicas()))
                            .type(DiffResult.DiffEntry.DiffType.CHANGED)
                            .build());
                }

                // Compare image tag
                if (!current.getImageTag().equals(entry.getImageTag())) {
                    diffs.add(DiffResult.DiffEntry.builder()
                            .field("image.tag")
                            .backupValue(entry.getImageTag())
                            .currentValue(current.getImageTag())
                            .type(DiffResult.DiffEntry.DiffType.CHANGED)
                            .build());
                }

                // Compare memory
                if (!current.getResources().getMemoryLimit().equals(entry.getMemoryLimit())) {
                    diffs.add(DiffResult.DiffEntry.builder()
                            .field("resources.memory.limit")
                            .backupValue(entry.getMemoryLimit())
                            .currentValue(current.getResources().getMemoryLimit())
                            .type(DiffResult.DiffEntry.DiffType.CHANGED)
                            .build());
                }

                // Compare configmap keys
                Map<String, String> backupCm = entry.getConfigMapData();
                Map<String, String> currentCmData = currentCm.getData();
                for (String key : backupCm.keySet()) {
                    String bv = backupCm.get(key);
                    String cv = currentCmData.get(key);
                    if (cv == null) {
                        diffs.add(DiffResult.DiffEntry.builder()
                                .field("configmap." + key)
                                .backupValue(bv).currentValue("(removed)")
                                .type(DiffResult.DiffEntry.DiffType.REMOVED).build());
                    } else if (!bv.equals(cv)) {
                        diffs.add(DiffResult.DiffEntry.builder()
                                .field("configmap." + key)
                                .backupValue(bv).currentValue(cv)
                                .type(DiffResult.DiffEntry.DiffType.CHANGED).build());
                    }
                }
                for (String key : currentCmData.keySet()) {
                    if (!backupCm.containsKey(key)) {
                        diffs.add(DiffResult.DiffEntry.builder()
                                .field("configmap." + key)
                                .backupValue("(new)").currentValue(currentCmData.get(key))
                                .type(DiffResult.DiffEntry.DiffType.ADDED).build());
                    }
                }

                if (!diffs.isEmpty()) {
                    results.add(DiffResult.builder()
                            .serviceName(entry.getServiceName())
                            .namespace(entry.getNamespace())
                            .differences(diffs)
                            .hasDiff(true)
                            .build());
                }
            }
            return results;
        }).orElse(Collections.emptyList());
    }

    // ─────────────────────────────────────────────
    //  STATS (for dashboard counters)
    // ─────────────────────────────────────────────

    public Map<String, Long> getPodStats(String env) {
        List<Pod> pods = getPodsForEnv(env);
        Map<String, Long> stats = new LinkedHashMap<>();
        stats.put("total", (long) pods.size());
        stats.put("running", pods.stream().filter(p -> "RUNNING".equals(p.getStatus())).count());
        stats.put("failed", pods.stream().filter(p -> "FAILED".equals(p.getStatus())).count());
        stats.put("crashLoop", pods.stream().filter(p -> "CRASH_LOOP".equals(p.getStatus())).count());
        return stats;
    }
}
