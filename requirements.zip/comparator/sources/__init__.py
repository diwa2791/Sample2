"""Source layer.

A source turns one backend's raw data into a ServiceSnapshot. Comparators only
ever see snapshots, so adding a new backend (another cluster, a rendered helm
template, a golden file) means writing one class here and nothing else.
"""

from comparator.sources.base import SnapshotSource
from comparator.sources.ado import AdoSource
from comparator.sources.k8s import KubernetesSource

__all__ = ["SnapshotSource", "AdoSource", "KubernetesSource"]
