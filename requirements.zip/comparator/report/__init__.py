"""Report layer."""

from comparator.report.html import HtmlReportRenderer

__all__ = ["HtmlReportRenderer"]
