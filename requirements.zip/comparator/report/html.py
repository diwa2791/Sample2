"""HTML rendering.

Presentation lives entirely in report/templates/report.html, so restyling the
report means editing that one file -- no Python changes. The renderer only
flattens the model into template-friendly rows.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from comparator.config import Config
from comparator.models import ComparisonReport, Status

TEMPLATE_DIR = Path(__file__).parent / "templates"

def _status_labels(left: str, right: str) -> Dict[Status, str]:
    """Status wording depends on what the two sides actually are."""
    return {
        Status.MATCH: "Match",
        Status.MISMATCH: "Mismatch",
        Status.MISSING_LEFT: f"Missing in {left}",
        Status.MISSING_RIGHT: f"Missing in {right}",
        Status.WARNING: "Warning",
    }


class HtmlReportRenderer:
    """Renders a ComparisonReport to a single self-contained HTML file."""

    def __init__(self, config: Config, template_name: str = "report.html") -> None:
        self.cfg = config
        self.template_name = template_name
        self.env = Environment(
            loader=FileSystemLoader(str(TEMPLATE_DIR)),
            autoescape=select_autoescape(["html"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def render(
        self,
        report: ComparisonReport,
        show_matches: bool = True,
        embedded: bool = False,
    ) -> str:
        """`embedded` drops the report's own sidebar: inside the web UI's
        iframe the hub already provides one, and two would just stack."""
        template = self.env.get_template(self.template_name)
        labels = _status_labels(
            report.context.get("left_label", "Left"),
            report.context.get("right_label", "Right"),
        )
        return template.render(
            ctx=report.context,
            embedded=embedded,
            summary=self._summary(report),
            services=[self._service(s, show_matches, labels) for s in report.services],
        )

    def write(
        self,
        report: ComparisonReport,
        output_path: Optional[str] = None,
        show_matches: bool = True,
    ) -> Path:
        target = Path(output_path or self.cfg.get("report.output_path", "report.html"))
        if not target.is_absolute():
            target = Path.cwd() / target
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.render(report, show_matches), encoding="utf-8")
        return target

    # -- flattening -------------------------------------------------------

    def _summary(self, report: ComparisonReport) -> Dict[str, Any]:
        total_keys = sum(
            len(a.differences) for s in report.services for a in s.aspects
        )
        total_services = len(report.services)
        in_sync = total_services - report.services_with_drift
        # How many services each branch turned out to own -- worth seeing when
        # the chart is split across branches.
        per_branch: Dict[str, int] = {}
        for svc in report.services:
            if svc.branch:
                per_branch[svc.branch] = per_branch.get(svc.branch, 0) + 1
        return {
            "per_branch": sorted(per_branch.items()),
            "branch_count": len(per_branch),
            "services": total_services,
            "services_with_drift": report.services_with_drift,
            "services_in_sync": in_sync,
            "total_drift": report.total_drift,
            "total_keys": total_keys,
            "issues": sum(len(s.issues) for s in report.services),
            "clean": report.total_drift == 0,
            "pct_in_sync": _pct(in_sync, total_services),
            "pct_drift": _pct(report.services_with_drift, total_services),
            "pct_keys_drift": _pct(report.total_drift, total_keys),
        }

    def _service(
        self, service: Any, show_matches: bool, labels: Dict[Status, str]
    ) -> Dict[str, Any]:
        aspects: List[Dict[str, Any]] = []
        for aspect in service.aspects:
            rows = [
                {
                    "key": d.key,
                    "left": _display(d.left_value),
                    "right": _display(d.right_value),
                    "status": d.status.value,
                    "label": labels.get(d.status, d.status.value),
                    "note": d.note,
                    "drift": d.is_drift,
                }
                for d in aspect.differences
                if show_matches or d.is_drift
            ]
            aspects.append(
                {
                    "name": aspect.aspect,
                    "title": aspect.aspect.replace("_", " ").title(),
                    "rows": rows,
                    "drift_count": aspect.drift_count,
                    "total": len(aspect.differences),
                    "has_drift": aspect.has_drift,
                }
            )
        return {
            "name": service.name,
            "branch": service.branch,
            "status": service.status.value,
            "label": labels.get(service.status, service.status.value),
            "drift_count": service.drift_count,
            "issues": service.issues,
            "aspects": aspects,
        }


def _pct(part: int, whole: int) -> str:
    if not whole:
        return "0%"
    return f"{round(part * 100 / whole)}%"


def _display(value: Optional[str]) -> str:
    if value is None:
        return "—"
    text = str(value)
    return text if text.strip() else "—"
