"""The local web hub: Kube2Branch, Folder2Folder and the config editor.

Stdlib http.server only -- no Flask, nothing new in requirements. It binds to
127.0.0.1 because it writes to your filesystem and holds a PAT field; it is a
local tool, not a service.

Comparisons here go through comparator.runner, the same path the CLI takes, so
a run means the same thing whichever way it was started.

Config values are shown exactly as the file has them, `${ENV:default}`
included, so saving cannot silently bake a placeholder into a literal. Where a
placeholder resolves to something different, the resolved value is shown
underneath as a read-only hint.
"""

from __future__ import annotations

import json
import logging
import shutil
import threading
import traceback
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import yaml
from jinja2 import Environment, FileSystemLoader, select_autoescape

from comparator.config import Config, _interpolate
from comparator.report.html import HtmlReportRenderer
from comparator.runner import (
    RunError,
    list_envs,
    run_build2build,
    run_folder2folder,
    run_kube2branch,
)
from comparator.webui.schema import SECTIONS, field_by_path
from comparator.webui.yaml_edit import apply_changes, dig_raw, load_raw

LOG = logging.getLogger(__name__)
TEMPLATE_DIR = Path(__file__).parent / "templates"

NAV = [
    ("/kube2branch", "Kube2Branch", "Declared helm values vs the live cluster"),
    ("/folder2folder", "Folder2Folder", "One env folder vs another, e.g. sit vs prd"),
    ("/build2build", "Build2Build", "The chart behind two CD pipeline runs, old vs new"),
    ("/config", "Config", "Edit config.yaml"),
]


# --------------------------------------------------------------------------
# value <-> widget conversion
# --------------------------------------------------------------------------

def to_widget(value: Any, widget: str) -> Any:
    """Render a raw YAML value for its input control."""
    if widget == "checkbox":
        return bool(value)
    if widget == "list":
        if isinstance(value, list):
            return "\n".join(str(v) for v in value)
        return "" if value in (None, "") else str(value)
    if widget == "map":
        if isinstance(value, dict):
            return "\n".join(f"{k}: {v}" for k, v in value.items())
        return ""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def from_widget(raw: Any, widget: str) -> Any:
    """Turn a posted control value back into something YAML-shaped."""
    if widget == "checkbox":
        return bool(raw)
    if widget == "number":
        text = str(raw).strip()
        if not text:
            return 0
        try:
            return int(text)
        except ValueError:
            return float(text)
    if widget == "list":
        return [line.strip() for line in str(raw).splitlines() if line.strip()]
    if widget == "map":
        out: Dict[str, str] = {}
        for line in str(raw).splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, sep, val = line.partition(":")
            if not sep:
                raise ValueError(f"Expected 'key: value', got {line!r}")
            out[key.strip()] = val.strip()
        return out
    return str(raw)


def build_view(text: str) -> List[Dict[str, Any]]:
    """Sections + fields + current values, ready for the template."""
    raw = load_raw(text)
    resolved = _interpolate(raw)
    view: List[Dict[str, Any]] = []
    for section in SECTIONS:
        fields = []
        for f in section.fields:
            raw_value = dig_raw(raw, f.path)
            eff_value = dig_raw(resolved, f.path)
            shown = to_widget(raw_value, f.widget)
            effective = to_widget(eff_value, f.widget)
            fields.append(
                {
                    "path": f.path,
                    "label": f.label,
                    "widget": f.widget,
                    "help": f.help,
                    "options": f.options or [],
                    "placeholder": f.placeholder,
                    "value": shown,
                    # Only worth showing when the placeholder resolves to
                    # something other than what is written in the file.
                    "effective": effective if effective != shown else "",
                }
            )
        view.append({"title": section.title, "blurb": section.blurb, "fields": fields})
    return view


# --------------------------------------------------------------------------
# saving
# --------------------------------------------------------------------------

def compute_changes(text: str, submitted: Dict[str, Any]) -> List[Tuple[str, str, Any]]:
    """Only rewrite what actually differs, so the diff stays small."""
    raw = load_raw(text)
    changes: List[Tuple[str, str, Any]] = []
    for path, posted in submitted.items():
        f = field_by_path(path)
        if f is None:
            continue  # not an exposed field; ignore rather than trust the client
        new_value = from_widget(posted, f.widget)
        current = dig_raw(raw, path)
        if f.widget == "list" and not isinstance(current, list):
            current = [] if current in (None, "") else current
        if new_value == current:
            continue
        changes.append((f.kind, path, new_value))
    return changes


def save(config_path: Path, submitted: Dict[str, Any]) -> Dict[str, Any]:
    """Apply, validate, back up, write. Returns a small result dict."""
    text = config_path.read_text(encoding="utf-8")
    changes = compute_changes(text, submitted)
    if not changes:
        return {"ok": True, "changed": [], "message": "No changes to save."}

    updated = apply_changes(text, changes)

    # Never write something we cannot read back.
    try:
        yaml.safe_load(updated)
    except yaml.YAMLError as exc:
        raise ValueError(f"Refusing to write: result is not valid YAML ({exc})")

    backup = config_path.with_suffix(config_path.suffix + ".bak")
    shutil.copy2(config_path, backup)
    config_path.write_text(updated, encoding="utf-8")

    return {
        "ok": True,
        "changed": [path for _, path, _ in changes],
        "message": "Saved {} change{} to {} (backup: {}).".format(
            len(changes), "" if len(changes) == 1 else "s", config_path.name, backup.name
        ),
    }


# --------------------------------------------------------------------------
# http
# --------------------------------------------------------------------------

class Hub:
    """Holds what the handler needs, plus the reports produced this session."""

    KEEP_REPORTS = 5

    def __init__(self, config_path: Path) -> None:
        self.config_path = config_path
        self.reports: Dict[str, str] = {}  # id -> rendered html
        self.env = Environment(
            loader=FileSystemLoader(str(TEMPLATE_DIR)),
            autoescape=select_autoescape(["html"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def config(self) -> Config:
        # Reloaded per request: the Config page may have just changed it.
        return Config.load(self.config_path)

    def render(self, template: str, active: str, **kwargs: Any) -> str:
        return self.env.get_template(template).render(
            nav=NAV, active=active, config_path=str(self.config_path), **kwargs
        )

    def store(self, kind: str, report: Any, cfg: Config, drift_only: bool) -> Dict[str, Any]:
        html = HtmlReportRenderer(cfg).render(
            report, show_matches=not drift_only, embedded=True
        )
        report_id = f"{kind}-{datetime.now().strftime('%H%M%S%f')}"
        self.reports[report_id] = html
        # Held in memory only: this is a local tool, not a report store.
        for old in list(self.reports)[: -self.KEEP_REPORTS]:
            self.reports.pop(old, None)
        return {
            "ok": True,
            "url": f"/report/{report_id}",
            "message": "{} service(s) compared · {} with drift · {} difference(s).".format(
                len(report.services), report.services_with_drift, report.total_drift
            ),
        }


def make_handler(hub: Hub):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            LOG.debug("%s - %s", self.address_string(), fmt % args)

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _html(self, body: str, code: int = 200) -> None:
            self._send(code, body.encode("utf-8"), "text/html; charset=utf-8")

        def _json(self, payload: Dict[str, Any], code: int = 200) -> None:
            self._send(code, json.dumps(payload).encode("utf-8"), "application/json")

        def _redirect(self, to: str) -> None:
            self.send_response(302)
            self.send_header("Location", to)
            self.end_headers()

        # -- GET ----------------------------------------------------------

        def do_GET(self) -> None:  # noqa: N802
            path = urlparse(self.path).path
            try:
                if path == "/":
                    return self._redirect("/kube2branch")
                if path == "/kube2branch":
                    return self._html(self._page_kube2branch())
                if path == "/folder2folder":
                    return self._html(self._page_folder2folder())
                if path == "/build2build":
                    return self._html(self._page_build2build())
                if path == "/config":
                    return self._html(
                        hub.render(
                            "config.html",
                            active="/config",
                            sections=build_view(
                                hub.config_path.read_text(encoding="utf-8")
                            ),
                        )
                    )
                if path.startswith("/report/"):
                    html = hub.reports.get(path.rsplit("/", 1)[-1])
                    if html is None:
                        return self._html(
                            "<p style='font:14px system-ui;padding:20px'>"
                            "That report is no longer held in memory. Run it again.</p>",
                            404,
                        )
                    return self._html(html)
                if path == "/raw":
                    body = hub.config_path.read_text(encoding="utf-8").encode("utf-8")
                    return self._send(200, body, "text/plain; charset=utf-8")
                self._send(404, b"not found", "text/plain")
            except Exception:
                LOG.exception("GET %s failed", path)
                self._html(f"<pre>{traceback.format_exc()}</pre>", 500)

        def _page_kube2branch(self) -> str:
            cfg = hub.config()
            return hub.render(
                "kube2branch.html",
                active="/kube2branch",
                cluster=cfg.get("target.cluster"),
                env=cfg.get("target.env"),
                namespace=cfg.get("connections.kubernetes.namespace"),
                context=cfg.get("connections.kubernetes.context") or "(current context)",
                mode=cfg.get("connections.azure_devops.mode"),
                services="\n".join(cfg.services),
            )

        def _page_folder2folder(self) -> str:
            cfg = hub.config()
            cluster = cfg.get("target.cluster")
            envs = list_envs(cfg, cluster)
            current = cfg.get("target.env")
            return hub.render(
                "folder2folder.html",
                active="/folder2folder",
                cluster=cluster,
                envs=envs,
                left=current if current in envs or not envs else (envs[0] if envs else ""),
                right=next((e for e in envs if e != current), ""),
                mode=cfg.get("connections.azure_devops.mode"),
            )

        def _page_build2build(self) -> str:
            cfg = hub.config()
            mode = (cfg.get("connections.azure_devops.mode") or "").strip().lower()
            return hub.render(
                "build2build.html",
                active="/build2build",
                cluster=cfg.get("target.cluster"),
                env=cfg.get("target.env"),
                mode=mode,
                # The pipeline API is only reachable over rest; say so up front
                # rather than after the user has pasted two URLs.
                rest_ready=mode == "rest",
                has_pat=bool(cfg.get("connections.azure_devops.pat")),
            )

        # -- POST ---------------------------------------------------------

        def do_POST(self) -> None:  # noqa: N802
            path = urlparse(self.path).path
            length = int(self.headers.get("Content-Length") or 0)
            payload = self.rfile.read(length).decode("utf-8") or "{}"
            try:
                body = json.loads(payload)
            except ValueError as exc:
                return self._json({"ok": False, "message": f"Bad request: {exc}"}, 400)

            try:
                if path == "/save":
                    return self._json(save(hub.config_path, body))
                if path == "/run/kube2branch":
                    return self._json(self._run_kube2branch(body))
                if path == "/run/folder2folder":
                    return self._json(self._run_folder2folder(body))
                if path == "/run/build2build":
                    return self._json(self._run_build2build(body))
                self._json({"ok": False, "message": "not found"}, 404)
            except (RunError, ValueError, KeyError, OSError) as exc:
                self._json({"ok": False, "message": str(exc)}, 400)
            except Exception as exc:  # keep the hub alive on surprises
                LOG.exception("POST %s failed", path)
                self._json({"ok": False, "message": f"Unexpected error: {exc}"}, 500)

        def _services(self, body: Dict[str, Any]) -> Optional[List[str]]:
            names = [
                s.strip() for s in str(body.get("services") or "").splitlines() if s.strip()
            ]
            return names or None

        def _run_kube2branch(self, body: Dict[str, Any]) -> Dict[str, Any]:
            cfg = hub.config()
            if body.get("namespace"):
                cfg.data["connections"]["kubernetes"]["namespace"] = body["namespace"]
            report = run_kube2branch(cfg, services=self._services(body))
            return hub.store("kube2branch", report, cfg, bool(body.get("drift_only")))

        def _run_folder2folder(self, body: Dict[str, Any]) -> Dict[str, Any]:
            cfg = hub.config()
            report = run_folder2folder(
                cfg,
                left_env=str(body.get("left") or "").strip(),
                right_env=str(body.get("right") or "").strip(),
                cluster=(body.get("cluster") or "").strip() or None,
                services=self._services(body),
            )
            return hub.store("folder2folder", report, cfg, bool(body.get("drift_only")))

        def _run_build2build(self, body: Dict[str, Any]) -> Dict[str, Any]:
            cfg = hub.config()
            report = run_build2build(
                cfg,
                old_url=str(body.get("old") or "").strip(),
                new_url=str(body.get("new") or "").strip(),
                cluster=(body.get("cluster") or "").strip() or None,
                env=(body.get("env") or "").strip() or None,
                services=self._services(body),
            )
            return hub.store("build2build", report, cfg, bool(body.get("drift_only")))

    return Handler


def serve(
    config_path: Path,
    port: int = 8765,
    open_browser: bool = True,
    host: str = "127.0.0.1",
    landing: str = "/kube2branch",
) -> None:
    """Run the hub until interrupted."""
    hub = Hub(config_path)
    httpd = HTTPServer((host, port), make_handler(hub))
    url = f"http://{host}:{port}{landing}"
    print(f"Comparator UI: {url}")
    print(f"Config file:   {config_path}")
    print("Press Ctrl+C to stop.")
    if open_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
