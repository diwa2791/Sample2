"""Source contract."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from comparator.models import ServiceSnapshot, Side


class SnapshotSource(ABC):
    """Produces a normalised ServiceSnapshot for a named service."""

    side: Side

    @abstractmethod
    def snapshot(self, service: str) -> ServiceSnapshot:
        """Read one service. Never raises for missing data -- it sets
        `found=False` and records the reason in `issues` instead, so one bad
        service does not abort the whole report."""

    def list_services(self) -> List[str]:
        """Every service this backend knows about.

        Used to discover what to compare when no explicit list is configured.
        A backend that cannot enumerate returns an empty list rather than
        raising -- discovery then falls back to whatever the other side knows.
        """
        return []
