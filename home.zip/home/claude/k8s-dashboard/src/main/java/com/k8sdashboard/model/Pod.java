package com.k8sdashboard.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@Getter
@Setter
public class Pod {
    private String name;
    private String namespace;
    private String status;           // RUNNING, FAILED, CRASH_LOOP
    private String deploymentName;
    private String image;
    private int restartCount;
    private String node;
    private String podIp;
    private int cpuMillicores;
    private int memoryMi;
    private int cpuLimitMillicores;
    private int memoryLimitMi;
    private LocalDateTime startTime;
    private int readyContainers;
    private int totalContainers;
    private String reason;           // for failed/crashloop
    private List<String> conditions;
    private Map<String, String> labels;

    public String getStatusClass() {
        return switch (status) {
            case "RUNNING" -> "status-running";
            case "FAILED" -> "status-failed";
            case "CRASH_LOOP" -> "status-crashloop";
            default -> "status-unknown";
        };
    }

    public String getStatusLabel() {
        return switch (status) {
            case "RUNNING" -> "Running";
            case "FAILED" -> "Failed";
            case "CRASH_LOOP" -> "CrashLoopBackOff";
            default -> "Unknown";
        };
    }

    public String getUptimeDisplay() {
        if (startTime == null) return "N/A";
        long hours = java.time.Duration.between(startTime, LocalDateTime.now()).toHours();
        if (hours < 1) return "< 1h";
        if (hours < 24) return hours + "h";
        return (hours / 24) + "d";
    }
}
