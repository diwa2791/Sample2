"""Which config settings the UI exposes, and how to render each one.

Adding a field here is all it takes for it to appear in the editor -- the
server and template are generic. `path` must exist in config.yaml; the editor
refuses to invent keys, so a typo here surfaces immediately rather than
writing a setting nobody reads.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class Field:
    path: str
    label: str
    widget: str = "text"          # text|password|number|checkbox|select|list|map
    help: str = ""
    options: Optional[List[str]] = None
    placeholder: str = ""

    @property
    def kind(self) -> str:
        """How yaml_edit should write it."""
        if self.widget == "list":
            return "list"
        if self.widget == "map":
            return "map"
        return "scalar"


@dataclass
class Section:
    title: str
    blurb: str
    fields: List[Field] = field(default_factory=list)


ENV_HINT = "Supports ${ENV_VAR:default} — keep it to read from the environment."

SECTIONS: List[Section] = [
    Section(
        title="Azure DevOps",
        blurb="Where the declared helm values are read from.",
        fields=[
            Field(
                "connections.azure_devops.mode",
                "Mode",
                "select",
                "'local' reads a checkout on disk (no PAT, no network). "
                "'rest' reads the real repo over HTTPS.",
                options=["local", "rest", "${ADO_MODE:local}"],
            ),
            Field("connections.azure_devops.organization", "Organization", help="rest mode only. " + ENV_HINT),
            Field("connections.azure_devops.project", "Project", help="rest mode only. " + ENV_HINT),
            Field("connections.azure_devops.repository", "Repository", help="rest mode only. " + ENV_HINT),
            Field("connections.azure_devops.base_url", "Base URL", help="rest mode only."),
            Field(
                "connections.azure_devops.pat",
                "Personal access token",
                "password",
                "Scope: Code (Read). Prefer leaving this as ${ADO_PAT:} and setting the "
                "environment variable — a literal token here lands in the file.",
            ),
            Field(
                "connections.azure_devops.branches",
                "Branches",
                help="Services split across branches: comma-separated, searched in order "
                "(e.g. branch1,branch2,branch3). Leave empty to use the single Branch below.",
                placeholder="branch1,branch2,branch3",
            ),
            Field("connections.azure_devops.branch", "Branch (single)", help="Used only when Branches is empty."),
            Field(
                "connections.azure_devops.root_path",
                "Local root path",
                help="local mode only. Relative paths resolve against this project folder.",
            ),
            Field(
                "connections.azure_devops.branch_roots",
                "Local branch roots",
                "map",
                "local mode only. One checkout per branch, as `branch: path` per line. "
                "When set, these replace the root path above.",
                placeholder="branch1: d:/checkouts/branch1",
            ),
            Field("connections.azure_devops.timeout_seconds", "Timeout (seconds)", "number"),
            Field("connections.azure_devops.verify_ssl", "Verify SSL", "checkbox"),
        ],
    ),
    Section(
        title="Kubernetes",
        blurb="The live cluster the declared state is compared against.",
        fields=[
            Field(
                "connections.kubernetes.mode",
                "Mode",
                "select",
                "'kubeconfig' for a workstation; 'in_cluster' when running as a pod.",
                options=["kubeconfig", "in_cluster", "${K8S_MODE:kubeconfig}"],
            ),
            Field(
                "connections.kubernetes.context",
                "Context",
                help="Empty means whatever kubectl currently points at. " + ENV_HINT,
                placeholder="(current context)",
            ),
            Field("connections.kubernetes.namespace", "Namespace", help=ENV_HINT),
            Field("connections.kubernetes.kubeconfig_path", "Kubeconfig path", help="Empty uses the default location."),
            Field("connections.kubernetes.timeout_seconds", "Timeout (seconds)", "number"),
        ],
    ),
    Section(
        title="Target",
        blurb="What gets compared.",
        fields=[
            Field("target.cluster", "Cluster", help="Fills {cluster} in the repo paths below."),
            Field("target.env", "Environment", help="Fills {env} in the repo paths below."),
            Field(
                "target.services",
                "Services",
                "list",
                "Leave EMPTY to discover automatically: everything the images files declare "
                "plus every deployment in the namespace. List services (one per line) only "
                "to narrow the run.",
                placeholder="(empty = discover everything)",
            ),
            Field(
                "target.exclude",
                "Exclude from discovery",
                "list",
                "One glob per line, for anything sharing the namespace that is not yours "
                "(e.g. redis-*). Ignored when Services is set explicitly.",
                placeholder="redis-*",
            ),
            Field(
                "target.service_branches",
                "Pinned service branches",
                "map",
                "Skip BRANCH discovery for specific services, as `service: branch` per line. "
                "Only for the odd one discovery gets wrong — not a list of your services.",
                placeholder="aa-amazon-owd01: branch2",
            ),
        ],
    ),
    Section(
        title="Comparison",
        blurb="Which checks run and how strict they are.",
        fields=[
            Field("comparison.enabled.configmap", "Compare ConfigMap", "checkbox"),
            Field("comparison.enabled.image", "Compare Image", "checkbox"),
            Field("comparison.enabled.resources", "Compare Resources", "checkbox"),
            Field("comparison.image.registry", "Image registry", help="Prefixed to imagePath to build the declared reference."),
            Field("comparison.image.compare_digest_only", "Compare digest only", "checkbox", "Ignore tag and registry drift."),
            Field(
                "comparison.image.tolerate_missing_digest",
                "Tolerate missing digest",
                "checkbox",
                "Report a warning rather than a mismatch when only one side has a digest.",
            ),
            Field("comparison.configmap.include_common", "Merge common.yaml properties", "checkbox"),
            Field(
                "comparison.configmap.ignore_key_globs",
                "Ignore keys (globs)",
                "list",
                "One glob per line. Matching keys are skipped entirely.",
                placeholder="logging.pattern.*",
            ),
            Field(
                "comparison.configmap.mask_value_globs",
                "Mask values (globs)",
                "list",
                "One glob per line. Compared for presence, but values are hidden in the report.",
                placeholder="*password*",
            ),
            Field(
                "comparison.resources.fields",
                "Resource fields",
                "list",
                "One dotted field per line. Compared after normalisation, so 2G and 2Gi do not read as drift.",
                placeholder="limits.memory",
            ),
        ],
    ),
    Section(
        title="Repo layout",
        blurb="Where the files sit inside the helm repo. {cluster}, {env} and {service} are filled in.",
        fields=[
            Field("repo_layout.images_file", "Images file"),
            Field("repo_layout.service_file", "Service values file"),
            Field("repo_layout.common_file", "Common file"),
            Field("repo_layout.images_root_key", "Images root key"),
            Field("repo_layout.microservices_root_key", "Microservices root key"),
            Field("repo_layout.service_properties_key", "Service properties key"),
        ],
    ),
    Section(
        title="Report",
        blurb="The generated HTML.",
        fields=[
            Field("report.title", "Title"),
            Field("report.output_path", "Output path", help=ENV_HINT),
            Field(
                "report.fail_on_mismatch",
                "Exit non-zero on drift",
                "checkbox",
                "Turn on to make CI fail when drift is found.",
            ),
        ],
    ),
]


def all_fields() -> List[Field]:
    return [f for section in SECTIONS for f in section.fields]


def field_by_path(path: str) -> Optional[Field]:
    for f in all_fields():
        if f.path == path:
            return f
    return None
