"""The two comparisons, in one place.

Both the CLI and the web UI call these, so a run means exactly the same thing
whichever way it was started. Everything that can go wrong before a report
exists raises RunError; callers decide how to show it.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from comparator.comparison.engine import ComparisonEngine
from comparator.config import Config
from comparator.connections.azure_devops import build_repo_connection
from comparator.connections.base import ConnectionError_, RepoConnection  # noqa: F401
from comparator.connections.kubernetes import KubernetesConnection
from comparator.models import ComparisonReport
from comparator.sources.ado import AdoSource
from comparator.sources.k8s import KubernetesSource

LOG = logging.getLogger(__name__)


class RunError(Exception):
    """A run could not produce a trustworthy report."""


def _checked_repo(cfg: Config, verify_branches: bool = True) -> RepoConnection:
    try:
        conn = build_repo_connection(cfg)
    except (ConnectionError_, ValueError) as exc:
        raise RunError(f"Azure DevOps connection setup failed: {exc}") from exc
    try:
        conn.check(verify_branches=verify_branches)
    except (ConnectionError_, ValueError) as exc:
        # A dead backend would otherwise produce a plausible-looking report in
        # which every service is merely "missing" -- worse than an error,
        # because it reads as a finding.
        raise RunError(f"Azure DevOps is not usable: {exc}") from exc
    return conn


def _checked_k8s(cfg: Config) -> KubernetesConnection:
    try:
        conn = KubernetesConnection.from_config(cfg)
        conn.check()
    except (ConnectionError_, ValueError) as exc:
        raise RunError(f"Kubernetes is not usable: {exc}") from exc
    return conn


def run_kube2branch(
    cfg: Config, services: Optional[List[str]] = None
) -> ComparisonReport:
    """Declared helm values (Azure DevOps) vs live cluster state."""
    repo_conn = _checked_repo(cfg)
    k8s_conn = _checked_k8s(cfg)

    cluster = cfg.get("target.cluster")
    env = cfg.get("target.env")
    namespace = cfg.get("connections.kubernetes.namespace")

    engine = ComparisonEngine(
        left_source=AdoSource(repo_conn, cfg),
        right_source=KubernetesSource(k8s_conn, cfg),
        config=cfg,
        left_label="Azure DevOps",
        right_label="Kubernetes",
        meta={
            "crumbs": f"{cluster} / {env} · namespace {namespace}",
            "footer": "{} mode vs {}".format(
                cfg.get("connections.azure_devops.mode"),
                cfg.get("connections.kubernetes.context") or "current context",
            ),
        },
    )

    chosen = services or cfg.services or engine.discover_services()
    if not chosen:
        raise RunError(
            "No services to compare: none configured in target.services, and "
            f"neither the images files nor namespace {namespace!r} yielded any."
        )
    return engine.run(chosen)


def run_folder2folder(
    cfg: Config,
    left_env: str,
    right_env: str,
    cluster: Optional[str] = None,
    services: Optional[List[str]] = None,
) -> ComparisonReport:
    """The same chart across two env folders (e.g. sit vs prd)."""
    if not left_env or not right_env:
        raise RunError("Both folders must be given.")
    if left_env == right_env:
        raise RunError(f"Nothing to compare: both sides are {left_env!r}.")

    repo_conn = _checked_repo(cfg)
    cluster = cluster or cfg.get("target.cluster")

    # Same connection, same branch: only `env` differs between the two sides.
    engine = ComparisonEngine(
        left_source=AdoSource(repo_conn, cfg, cluster=cluster, env=left_env),
        right_source=AdoSource(repo_conn, cfg, cluster=cluster, env=right_env),
        config=cfg,
        left_label=left_env,
        right_label=right_env,
        meta={
            "title": f"{left_env} vs {right_env} · {cluster}",
            "crumbs": f"cluster {cluster} · folder {left_env} vs {right_env}",
            "footer": "{} mode".format(cfg.get("connections.azure_devops.mode")),
        },
    )

    chosen = services or engine.discover_services()
    if not chosen:
        raise RunError(f"No services declared for cluster {cluster!r}.")
    return engine.run(chosen)


def run_build2build(
    cfg: Config,
    old_url: str,
    new_url: str,
    cluster: Optional[str] = None,
    env: Optional[str] = None,
    services: Optional[List[str]] = None,
) -> ComparisonReport:
    """Two CD pipeline runs, compared at the commits they were built from.

    Each run resolves to a sourceVersion; the chart is then read *at that
    commit* on both sides, so this is the same left/right comparison as the
    others -- two points in the repo's history rather than two folders.
    """
    from comparator.connections.ado_builds import AdoBuildClient

    if (cfg.get("connections.azure_devops.mode") or "").strip().lower() != "rest":
        raise RunError(
            "Build2Build needs the pipeline API, so it only works in 'rest' mode. "
            "Set connections.azure_devops.mode to 'rest' (and a PAT with Build "
            "(Read) + Code (Read))."
        )

    try:
        client = AdoBuildClient.from_config(cfg)
        old = client.get_build(old_url)
        new = client.get_build(new_url)
    except (ConnectionError_, ValueError) as exc:
        raise RunError(str(exc)) from exc

    if old.commit == new.commit:
        raise RunError(
            f"Nothing to compare: both builds were built from the same commit "
            f"({old.short_commit})."
        )

    # The chart must be what the builds were built from, or we would be reading
    # a different repo's tree at a sha that means nothing there.
    configured = (cfg.get("connections.azure_devops.repository") or "").strip()
    for build in (old, new):
        if configured and build.repository and build.repository != configured:
            raise RunError(
                f"Build {build.number or build.id} was built from repository "
                f"{build.repository!r}, not {configured!r}. Its commit "
                f"({build.short_commit}) does not exist in the chart repo, so "
                f"there is nothing to read there."
            )

    # Each side is pinned to a build's commit, so the configured branches are
    # irrelevant here -- validating them would fail runs for no reason.
    repo_conn = _checked_repo(cfg, verify_branches=False)
    cluster = cluster or cfg.get("target.cluster")
    env = env or cfg.get("target.env")

    engine = ComparisonEngine(
        left_source=AdoSource(repo_conn, cfg, cluster=cluster, env=env, ref=old.commit),
        right_source=AdoSource(repo_conn, cfg, cluster=cluster, env=env, ref=new.commit),
        config=cfg,
        left_label=old.label,
        right_label=new.label,
        meta={
            "title": f"{old.label} → {new.label} · {cluster}/{env}",
            "crumbs": f"{cluster}/{env} · {old.short_commit} → {new.short_commit}",
            "footer": f"old: {old.describe()} — new: {new.describe()}",
            "old_build": old,
            "new_build": new,
        },
    )

    chosen = services or engine.discover_services()
    if not chosen:
        raise RunError(
            "Neither build's images file declares any service. Check that "
            f"{cfg.get('repo_layout.images_file')} exists at both commits."
        )
    return engine.run(chosen)


def list_envs(cfg: Config, cluster: Optional[str] = None) -> List[str]:
    """Env folders available for a cluster, for the UI's dropdowns.

    Only local mode can enumerate directories; over REST we would need a tree
    walk, so callers fall back to free text there.
    """
    from comparator.connections.azure_devops import LocalRepoConnection

    try:
        conn = build_repo_connection(cfg)
    except (ConnectionError_, ValueError):
        return []
    if not isinstance(conn, LocalRepoConnection):
        return []

    cluster = cluster or cfg.get("target.cluster")
    template = cfg.get("repo_layout.service_file", "")
    # Derive the env directory from the service-file template by cutting it at
    # the {env} placeholder, so this keeps working if the layout changes.
    marker = "{env}"
    if marker not in template:
        return []
    prefix = template.split(marker)[0].format(cluster=cluster, service="")
    try:
        base = conn._resolve(prefix.rstrip("/"))
    except ConnectionError_:
        return []
    if not base.is_dir():
        return []
    return sorted(p.name for p in base.iterdir() if p.is_dir())
