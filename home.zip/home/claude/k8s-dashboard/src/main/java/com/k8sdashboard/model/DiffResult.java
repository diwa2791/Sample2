package com.k8sdashboard.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@Getter
@Setter
public class DiffResult {
    private String serviceName;
    private String namespace;
    private List<DiffEntry> differences;
    private boolean hasDiff;

    @Data
    @Builder
    @Getter
    @Setter
    public static class DiffEntry {
        private String field;
        private String backupValue;
        private String currentValue;
        private DiffType type;

        public enum DiffType {
            CHANGED, ADDED, REMOVED
        }

        public String getTypeClass() {
            return switch (type) {
                case CHANGED -> "diff-changed";
                case ADDED -> "diff-added";
                case REMOVED -> "diff-removed";
            };
        }

        public String getTypeLabel() {
            return switch (type) {
                case CHANGED -> "Changed";
                case ADDED -> "Added";
                case REMOVED -> "Removed";
            };
        }
    }
}
