/* ================================================================
   K8s Dashboard – dashboard.js
   Vanilla JS: no heavy framework, minimal DOM churn.
   All modal content is built once and re-used.
   ================================================================ */

'use strict';

// ── Toast ──────────────────────────────────────────────────────
const Toast = (() => {
  let container;
  function init() {
    container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
  }
  function show(message, type = 'info', duration = 3500) {
    if (!container) init();
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<span>${message}</span>`;
    container.appendChild(t);
    requestAnimationFrame(() => { requestAnimationFrame(() => t.classList.add('show')); });
    setTimeout(() => {
      t.classList.remove('show');
      setTimeout(() => t.remove(), 320);
    }, duration);
  }
  return { show };
})();

// ── Modal ──────────────────────────────────────────────────────
const Modal = (() => {
  let overlay, modal, titleEl, bodyEl, footerEl;
  function init() {
    overlay = document.getElementById('modal-overlay');
    modal   = overlay?.querySelector('.modal');
    titleEl = overlay?.querySelector('#modal-title');
    bodyEl  = overlay?.querySelector('#modal-body');
    footerEl= overlay?.querySelector('#modal-footer');
    overlay?.addEventListener('click', e => { if (e.target === overlay) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
    overlay?.querySelector('.modal-close')?.addEventListener('click', close);
  }
  function open(title, bodyHTML, footerHTML, large = false) {
    if (!overlay) init();
    titleEl.textContent = title;
    bodyEl.innerHTML = bodyHTML;
    footerEl.innerHTML = footerHTML || '<button class="btn btn-ghost" onclick="Modal.close()">Close</button>';
    modal.classList.toggle('modal-lg', large);
    overlay.classList.add('open');
  }
  function close() {
    overlay?.classList.remove('open');
    // Clear body after transition to free memory
    setTimeout(() => { if (bodyEl) bodyEl.innerHTML = ''; }, 250);
  }
  function setLoading(msg = 'Loading…') {
    if (bodyEl) bodyEl.innerHTML = `<div class="loading-overlay"><span class="spinner"></span>${msg}</div>`;
  }
  return { open, close, setLoading, init };
})();

// ── API helpers ────────────────────────────────────────────────
async function apiGet(url) {
  const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
async function apiPost(url, body) {
  const opts = { method: 'POST', headers: { 'Accept': 'application/json' } };
  if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
async function apiPut(url, body) {
  const r = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

// ── Clock ──────────────────────────────────────────────────────
function startClock() {
  const el = document.getElementById('topbar-time');
  if (!el) return;
  const tick = () => { el.textContent = new Date().toLocaleTimeString(); };
  tick(); setInterval(tick, 1000);
}

// ── Search (debounced) ─────────────────────────────────────────
function initSearch() {
  const inp = document.getElementById('search-input');
  if (!inp) return;
  let t;
  inp.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(() => {
      const url = new URL(window.location.href);
      url.searchParams.set('search', inp.value);
      url.searchParams.set('page', '0');
      window.location.href = url.toString();
    }, 400);
  });
}

// ── Scale Modal ────────────────────────────────────────────────
function openScaleModal(deploymentName, currentReplicas, env) {
  let count = parseInt(currentReplicas) || 1;
  const render = () => `
    <p style="color:var(--text-secondary);font-size:13px;margin-bottom:16px;">
      Deployment: <span style="color:var(--text-primary);font-family:var(--font-mono)">${deploymentName}</span>
    </p>
    <div style="display:flex;align-items:center;justify-content:center;padding:16px 0;">
      <div class="scale-control">
        <button class="scale-btn" id="scale-dec" ${count<=0?'disabled':''}>−</button>
        <div class="scale-num" id="scale-val">${count}</div>
        <button class="scale-btn" id="scale-inc" ${count>=20?'disabled':''}>+</button>
      </div>
    </div>
    <p style="text-align:center;font-size:11px;color:var(--text-muted);">Range: 0 – 20 replicas</p>
  `;

  const footer = `
    <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
    <button class="btn btn-primary" id="scale-confirm-btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      Apply Scale
    </button>
  `;

  Modal.open(`Scale Deployment`, render(), footer);

  // Wire up buttons after modal opens
  requestAnimationFrame(() => {
    document.getElementById('scale-dec')?.addEventListener('click', () => {
      if (count > 0) { count--; update(); }
    });
    document.getElementById('scale-inc')?.addEventListener('click', () => {
      if (count < 20) { count++; update(); }
    });
    document.getElementById('scale-confirm-btn')?.addEventListener('click', () => doScale());
  });

  function update() {
    const v = document.getElementById('scale-val');
    const dec = document.getElementById('scale-dec');
    const inc = document.getElementById('scale-inc');
    if (v) v.textContent = count;
    if (dec) dec.disabled = count <= 0;
    if (inc) inc.disabled = count >= 20;
  }

  async function doScale() {
    const btn = document.getElementById('scale-confirm-btn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Scaling…'; }
    try {
      const res = await apiPost(`/${env.toLowerCase()}/api/pods/${deploymentName}/scale?replicas=${count}`);
      Toast.show(res.message || 'Scaled successfully', 'success');
      Modal.close();
      setTimeout(() => location.reload(), 800);
    } catch (e) {
      Toast.show('Scale failed: ' + e.message, 'error');
      if (btn) { btn.disabled = false; btn.textContent = 'Apply Scale'; }
    }
  }
}

// ── ConfigMap Modal ────────────────────────────────────────────
async function openConfigMapModal(deploymentName, env) {
  Modal.open('Edit ConfigMap', '', '', true);
  Modal.setLoading('Fetching ConfigMap…');

  try {
    const res = await apiGet(`/${env.toLowerCase()}/api/pods/${deploymentName}/configmap`);
    const cm = res.data;
    const entries = Object.entries(cm.data || {});

    const rows = entries.map(([k, v]) => `
      <div class="cm-entry" data-key="${escHtml(k)}">
        <input class="cm-key" value="${escHtml(k)}" readonly title="${escHtml(k)}">
        <input class="cm-val" value="${escHtml(v)}" data-orig="${escHtml(v)}">
        <button class="btn-icon" onclick="this.closest('.cm-entry').remove()" title="Remove key">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
    `).join('');

    const bodyHTML = `
      <div style="margin-bottom:12px;">
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">
          ConfigMap: <span style="color:var(--text-code);font-family:var(--font-mono)">${escHtml(cm.name)}</span>
          &nbsp;·&nbsp; Namespace: <span style="color:var(--text-code);font-family:var(--font-mono)">${escHtml(cm.namespace)}</span>
        </div>
        <div id="cm-entries">${rows}</div>
        <button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="addCmRow()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M12 5v14M5 12h14"/></svg>
          Add key
        </button>
      </div>
    `;
    const footerHTML = `
      <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
      <button class="btn btn-primary" onclick="saveConfigMap('${deploymentName}','${env}')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
        Save ConfigMap
      </button>
    `;
    const b = document.getElementById('modal-body');
    const f = document.getElementById('modal-footer');
    if (b) b.innerHTML = bodyHTML;
    if (f) f.innerHTML = footerHTML;
  } catch (e) {
    const b = document.getElementById('modal-body');
    if (b) b.innerHTML = `<p style="color:var(--accent-red)">Failed to load ConfigMap: ${e.message}</p>`;
  }
}

function addCmRow() {
  const container = document.getElementById('cm-entries');
  if (!container) return;
  const div = document.createElement('div');
  div.className = 'cm-entry';
  div.innerHTML = `
    <input class="cm-key" placeholder="key" value="">
    <input class="cm-val" placeholder="value" value="">
    <button class="btn-icon" onclick="this.closest('.cm-entry').remove()" title="Remove">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
    </button>
  `;
  container.appendChild(div);
  div.querySelector('.cm-key').focus();
}

async function saveConfigMap(deploymentName, env) {
  const entries = document.querySelectorAll('#cm-entries .cm-entry');
  const data = {};
  entries.forEach(row => {
    const key = row.querySelector('.cm-key')?.value?.trim();
    const val = row.querySelector('.cm-val')?.value?.trim();
    if (key) data[key] = val || '';
  });

  const btn = document.querySelector('#modal-footer .btn-primary');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving…'; }

  try {
    const res = await apiPut(`/${env.toLowerCase()}/api/pods/${deploymentName}/configmap`, data);
    Toast.show(res.message || 'ConfigMap saved', 'success');
    Modal.close();
  } catch (e) {
    Toast.show('Save failed: ' + e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Save ConfigMap'; }
  }
}

// ── Deployment Config Modal ────────────────────────────────────
async function openDeploymentModal(deploymentName, env) {
  Modal.open('Edit Deployment', '', '', true);
  Modal.setLoading('Fetching deployment config…');

  try {
    const res = await apiGet(`/${env.toLowerCase()}/api/pods/${deploymentName}/deployment`);
    const dep = res.data;
    const r = dep.resources || {};

    const bodyHTML = `
      <div class="form-group">
        <label>Image</label>
        <input class="form-control mono" id="dep-image" value="${escHtml(dep.image || '')}">
      </div>
      <div class="form-group">
        <label>Image Tag</label>
        <input class="form-control mono" id="dep-tag" value="${escHtml(dep.imageTag || '')}">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Replicas</label>
          <input class="form-control mono" id="dep-replicas" type="number" min="0" max="20" value="${dep.replicas || 1}">
        </div>
        <div class="form-group">
          <label>Strategy</label>
          <select class="form-control" id="dep-strategy">
            <option ${dep.strategy==='RollingUpdate'?'selected':''}>RollingUpdate</option>
            <option ${dep.strategy==='Recreate'?'selected':''}>Recreate</option>
          </select>
        </div>
      </div>
      <div style="font-size:12px;font-weight:600;color:var(--text-secondary);margin:12px 0 8px;text-transform:uppercase;letter-spacing:.5px;">Resources</div>
      <div class="form-row">
        <div class="form-group">
          <label>CPU Request</label>
          <input class="form-control mono" id="dep-cpu-req" value="${escHtml(r.cpuRequest||'100m')}">
          <div class="form-hint">e.g. 100m, 500m, 1</div>
        </div>
        <div class="form-group">
          <label>CPU Limit</label>
          <input class="form-control mono" id="dep-cpu-lim" value="${escHtml(r.cpuLimit||'500m')}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Memory Request</label>
          <input class="form-control mono" id="dep-mem-req" value="${escHtml(r.memoryRequest||'128Mi')}">
          <div class="form-hint">e.g. 128Mi, 512Mi, 1Gi</div>
        </div>
        <div class="form-group">
          <label>Memory Limit</label>
          <input class="form-control mono" id="dep-mem-lim" value="${escHtml(r.memoryLimit||'512Mi')}">
        </div>
      </div>
    `;
    const footerHTML = `
      <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
      <button class="btn btn-primary" onclick="saveDeployment('${deploymentName}','${env}')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
        Save Deployment
      </button>
    `;
    const b = document.getElementById('modal-body');
    const f = document.getElementById('modal-footer');
    if (b) b.innerHTML = bodyHTML;
    if (f) f.innerHTML = footerHTML;
  } catch (e) {
    const b = document.getElementById('modal-body');
    if (b) b.innerHTML = `<p style="color:var(--accent-red)">Failed to load deployment: ${e.message}</p>`;
  }
}

async function saveDeployment(deploymentName, env) {
  const payload = {
    name: deploymentName,
    image: document.getElementById('dep-image')?.value,
    imageTag: document.getElementById('dep-tag')?.value,
    replicas: parseInt(document.getElementById('dep-replicas')?.value) || 1,
    strategy: document.getElementById('dep-strategy')?.value,
    resources: {
      cpuRequest:    document.getElementById('dep-cpu-req')?.value,
      cpuLimit:      document.getElementById('dep-cpu-lim')?.value,
      memoryRequest: document.getElementById('dep-mem-req')?.value,
      memoryLimit:   document.getElementById('dep-mem-lim')?.value,
    }
  };

  const btn = document.querySelector('#modal-footer .btn-primary');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving…'; }

  try {
    const res = await apiPut(`/${env.toLowerCase()}/api/pods/${deploymentName}/deployment`, payload);
    Toast.show(res.message || 'Deployment updated', 'success');
    Modal.close();
    setTimeout(() => location.reload(), 800);
  } catch (e) {
    Toast.show('Save failed: ' + e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Save Deployment'; }
  }
}

// ── Logs Modal ────────────────────────────────────────────────
async function openLogsModal(podName, env) {
  Modal.open(`Logs — ${podName}`, '', '', true);
  Modal.setLoading('Fetching logs…');

  try {
    const res = await apiGet(`/${env.toLowerCase()}/api/pods/${podName}/logs/view?lines=150`);
    const raw = res.data || '';
    const colored = raw
      .split('\n')
      .map(line => {
        const cls = line.includes(' ERROR ') ? 'log-ERROR'
                  : line.includes(' WARN ')  ? 'log-WARN'
                  : line.includes(' DEBUG ') ? 'log-DEBUG'
                  : 'log-INFO';
        return `<span class="${cls}">${escHtml(line)}</span>`;
      }).join('\n');

    const bodyHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <div style="font-size:11px;color:var(--text-muted);">Showing last 150 lines</div>
        <div style="display:flex;gap:6px;">
          <select class="form-control mono" id="log-lines-sel" style="width:auto;padding:4px 8px;font-size:11px;">
            <option value="50">50 lines</option>
            <option value="150" selected>150 lines</option>
            <option value="300">300 lines</option>
            <option value="500">500 lines</option>
          </select>
          <button class="btn btn-ghost btn-sm" onclick="reloadLogs('${podName}','${env}')">Reload</button>
        </div>
      </div>
      <div class="log-viewer" id="log-viewer">${colored}</div>
    `;
    const footerHTML = `
      <button class="btn btn-ghost" onclick="Modal.close()">Close</button>
      <a class="btn btn-primary" href="/${env.toLowerCase()}/api/pods/${podName}/logs?lines=500" download="${podName}.log">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Download Logs
      </a>
    `;
    const b = document.getElementById('modal-body');
    const f = document.getElementById('modal-footer');
    if (b) b.innerHTML = bodyHTML;
    if (f) f.innerHTML = footerHTML;
    // Scroll log viewer to bottom
    const lv = document.getElementById('log-viewer');
    if (lv) lv.scrollTop = lv.scrollHeight;
  } catch (e) {
    const b = document.getElementById('modal-body');
    if (b) b.innerHTML = `<p style="color:var(--accent-red)">Failed to load logs: ${e.message}</p>`;
  }
}

async function reloadLogs(podName, env) {
  const lines = document.getElementById('log-lines-sel')?.value || 150;
  const lv = document.getElementById('log-viewer');
  if (lv) lv.innerHTML = '<div class="loading-overlay"><span class="spinner"></span> Reloading…</div>';
  try {
    const res = await apiGet(`/${env.toLowerCase()}/api/pods/${podName}/logs/view?lines=${lines}`);
    const colored = (res.data || '').split('\n').map(line => {
      const cls = line.includes(' ERROR ') ? 'log-ERROR'
                : line.includes(' WARN ')  ? 'log-WARN'
                : line.includes(' DEBUG ') ? 'log-DEBUG' : 'log-INFO';
      return `<span class="${cls}">${escHtml(line)}</span>`;
    }).join('\n');
    if (lv) { lv.innerHTML = colored; lv.scrollTop = lv.scrollHeight; }
  } catch (e) { Toast.show('Reload failed', 'error'); }
}

// ── Backup ────────────────────────────────────────────────────
async function createBackup(env) {
  const btn = document.getElementById('backup-btn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Creating backup…'; }
  try {
    const res = await apiPost(`/${env.toLowerCase()}/api/backup`);
    Toast.show(res.message || 'Backup created', 'success', 4000);
    setTimeout(() => location.reload(), 1200);
  } catch (e) {
    Toast.show('Backup failed: ' + e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Take Backup'; }
  }
}

// ── Diff (PRD) ────────────────────────────────────────────────
function expandDiff(el) {
  const row = el.closest('.diff-section');
  const body = row?.querySelector('.diff-body');
  if (!body) return;
  const hidden = body.style.display === 'none' || body.style.display === '';
  body.style.display = hidden ? 'block' : 'none';
  el.classList.toggle('expanded', hidden);
}

// ── Utility ───────────────────────────────────────────────────
function escHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  Modal.init();
  startClock();
  initSearch();
});
