"""Discovering what to compare when target.services is empty."""

from typing import List

from comparator.comparison.engine import ComparisonEngine
from comparator.config import Config
from comparator.models import ServiceSnapshot, Side


class FakeSource:
    def __init__(self, side: Side, services: List[str]) -> None:
        self.side = side
        self._services = services

    def list_services(self) -> List[str]:
        return list(self._services)

    def snapshot(self, service: str) -> ServiceSnapshot:
        snap = ServiceSnapshot(name=service, side=self.side)
        snap.found = service in self._services
        return snap


def make_engine(declared, running, exclude=None) -> ComparisonEngine:
    cfg = Config(
        {
            "target": {"exclude": exclude or []},
            "comparison": {"enabled": {}},
            "connections": {"azure_devops": {}, "kubernetes": {}},
            "report": {},
        }
    )
    return ComparisonEngine(
        FakeSource(Side.LEFT, declared), FakeSource(Side.RIGHT, running), cfg
    )


def test_union_of_both_sides():
    engine = make_engine(["a", "b"], ["b", "c"])
    assert engine.discover_services() == ["a", "b", "c"]


def test_service_declared_but_not_deployed_is_included():
    # The whole reason for a union: hand-listing would never surface this.
    engine = make_engine(["a", "ghost"], ["a"])
    assert "ghost" in engine.discover_services()


def test_service_deployed_but_not_declared_is_included():
    engine = make_engine(["a"], ["a", "rogue"])
    assert "rogue" in engine.discover_services()


def test_result_is_sorted_and_deduplicated():
    engine = make_engine(["b", "a", "b"], ["a", "c"])
    assert engine.discover_services() == ["a", "b", "c"]


def test_exclude_globs_are_applied():
    engine = make_engine(["aa-svc", "redis-cache"], ["redis-primary", "aa-svc"], exclude=["redis-*"])
    assert engine.discover_services() == ["aa-svc"]


def test_exclude_can_match_several_patterns():
    engine = make_engine(["a-1", "b-1", "keep"], [], exclude=["a-*", "b-*"])
    assert engine.discover_services() == ["keep"]


def test_no_services_anywhere_returns_empty_not_error():
    engine = make_engine([], [])
    assert engine.discover_services() == []


def test_one_side_unable_to_enumerate_still_discovers_the_other():
    # A source that cannot list returns [] rather than raising.
    engine = make_engine([], ["only-running"])
    assert engine.discover_services() == ["only-running"]


def test_discovered_services_compare_and_report_the_gap():
    engine = make_engine(["declared-only"], ["running-only"])
    report = engine.run(engine.discover_services())
    by_name = {s.name: s for s in report.services}
    assert by_name["declared-only"].right_found is False
    assert by_name["declared-only"].left_found is True
    assert by_name["running-only"].left_found is False
    assert by_name["running-only"].right_found is True
