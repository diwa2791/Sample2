"""Covers the malformed-YAML handling the real helm files require."""

from comparator.utils.yaml_utils import (
    extract_block,
    parse_properties,
    safe_load_lenient,
)

# Mirrors the real file: tabs at an 8-column stop, `key:value` with no space,
# and a serviceProperties block that is not a YAML block scalar.
MESSY = (
    "helm-chart:\n"
    "  microservices:\n"
    "     aa-amazon-owd01:\n"
    "        service:\n"
    "  \t   port: 8080\n"
    "\t   type: Cluster\n"
    "        replicaCount:1\n"
    "        resources: \n"
    "\t   limits:\n"
    "\t      memory:2G\n"
    "\t   requests:\n"
    "\t      memory:1G\n"
    "        serviceProperties:\n"
    "                server.port=8080\n"
    "                app.name=amazon\n"
)


def test_extract_block_pulls_properties_and_leaves_valid_yaml():
    remaining, block = extract_block(MESSY, "serviceProperties")
    assert "server.port=8080" in block
    assert "serviceProperties" not in remaining
    assert "replicaCount" in remaining


def test_messy_yaml_parses_after_repair():
    remaining, _ = extract_block(MESSY, "serviceProperties")
    data, issues = safe_load_lenient(remaining)
    node = data["helm-chart"]["microservices"]["aa-amazon-owd01"]
    assert node["replicaCount"] == 1
    assert node["resources"]["limits"]["memory"] == "2G"
    assert node["service"]["port"] == 8080
    assert issues, "repairing bad YAML must be reported, not silent"


def test_valid_yaml_reports_no_issues():
    data, issues = safe_load_lenient("a:\n  b: 1\n")
    assert data == {"a": {"b": 1}}
    assert issues == []


def test_unparseable_yaml_returns_empty_with_reason():
    data, issues = safe_load_lenient("a:\n  - [unclosed\n")
    assert data == {}
    assert any("invalid YAML" in i for i in issues)


def test_value_containing_colon_is_quoted_not_dropped():
    # Mirrors common.yaml. `database:xyz:` is only rejected once `env:sss`
    # has established the block as a mapping -- in isolation YAML would read
    # it as the key "database:xyz", so the surrounding line matters.
    data, issues = safe_load_lenient("helm-chart:\n  env:sss\n  database:xyz:\n")
    assert data["helm-chart"]["env"] == "sss"
    assert data["helm-chart"]["database"] == "xyz:"
    assert issues


def test_parse_properties_handles_both_separators_and_comments():
    props = parse_properties(
        "# comment\n"
        "server.port=8080\n"
        "app.port:9090\n"
        "\n"
        "url=https://x.com/a:b\n"
    )
    assert props == {
        "server.port": "8080",
        "app.port": "9090",
        "url": "https://x.com/a:b",
    }
