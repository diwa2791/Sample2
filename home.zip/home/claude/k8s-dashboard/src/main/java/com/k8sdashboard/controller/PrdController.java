package com.k8sdashboard.controller;

import com.k8sdashboard.model.*;
import com.k8sdashboard.service.MockDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/prd")
@RequiredArgsConstructor
public class PrdController {

    private final MockDataService dataService;
    private static final String ENV = "PRD";

    // ── Pages ──────────────────────────────────────────────────

    @GetMapping
    public String prdDashboard(
            @RequestParam(defaultValue = "") String search,
            Model model) {

        Map<String, Long> stats = dataService.getPodStats(ENV);
        List<Backup> backups = dataService.getBackups(ENV);

        model.addAttribute("env", ENV);
        model.addAttribute("stats", stats);
        model.addAttribute("backups", backups);
        model.addAttribute("search", search);
        return "prd/index";
    }

    @GetMapping("/diff/{backupId}")
    public String diffPage(@PathVariable String backupId, Model model) {
        List<DiffResult> diffs = dataService.compareBackupWithCurrent(backupId);
        dataService.getBackupById(backupId).ifPresent(b -> model.addAttribute("backup", b));
        model.addAttribute("diffs", diffs);
        model.addAttribute("diffCount", diffs.size());
        model.addAttribute("env", ENV);
        return "prd/diff";
    }

    // ── REST: Backup ───────────────────────────────────────────

    @PostMapping("/api/backup")
    @ResponseBody
    public ApiResponse<Backup> createBackup() {
        Backup backup = dataService.createBackup(ENV);
        return ApiResponse.ok("PRD Backup created: " + backup.getId(), backup);
    }

    @GetMapping("/api/backups")
    @ResponseBody
    public ApiResponse<List<Backup>> listBackups() {
        return ApiResponse.ok("OK", dataService.getBackups(ENV));
    }

    // ── REST: Diff ─────────────────────────────────────────────

    @GetMapping("/api/diff/{backupId}")
    @ResponseBody
    public ApiResponse<List<DiffResult>> getDiff(@PathVariable String backupId) {
        List<DiffResult> diffs = dataService.compareBackupWithCurrent(backupId);
        return ApiResponse.ok("Diff computed: " + diffs.size() + " services changed", diffs);
    }

    // ── REST: Pods overview ────────────────────────────────────

    @GetMapping("/api/pods")
    @ResponseBody
    public ApiResponse<List<Pod>> getPods(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "") String search) {

        List<Pod> pods = dataService.getPodsByStatus(ENV, "RUNNING");
        if (!search.isBlank()) {
            String q = search.toLowerCase();
            pods = pods.stream()
                    .filter(p -> p.getName().toLowerCase().contains(q)
                            || p.getDeploymentName().toLowerCase().contains(q))
                    .toList();
        }
        int total = pods.size();
        int from = Math.min(page * size, total);
        int to = Math.min(from + size, total);
        return ApiResponse.ok("Page " + page, pods.subList(from, to));
    }

    @GetMapping("/api/stats")
    @ResponseBody
    public ApiResponse<Map<String, Long>> getStats() {
        return ApiResponse.ok("OK", dataService.getPodStats(ENV));
    }
}
