"""Connection layer.

Each external system gets its own module and is responsible only for
*transport* -- authenticating and returning raw bytes/objects. Parsing and
interpretation live in comparator.sources, so a new backend (Git, S3, Vault,
another cluster) only needs a new connection here.
"""

from comparator.connections.base import Connection, ConnectionError_
from comparator.connections.azure_devops import (
    AzureDevOpsConnection,
    LocalRepoConnection,
    build_repo_connection,
)
from comparator.connections.kubernetes import KubernetesConnection

__all__ = [
    "Connection",
    "ConnectionError_",
    "AzureDevOpsConnection",
    "LocalRepoConnection",
    "build_repo_connection",
    "KubernetesConnection",
]
