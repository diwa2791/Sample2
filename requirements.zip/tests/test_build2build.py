"""Build2Build: two pipeline runs, compared at the commits behind them.

The interesting half is the HTTP contract with Azure DevOps, so most of this
runs against a stub ADO server rather than a mock: it exercises URL parsing,
auth headers, the Build API call, and -- the part easiest to get wrong --
asking the Items API for a *commit* rather than a branch.
"""

import base64
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

import pytest

from comparator.config import Config
from comparator.connections.ado_builds import AdoBuildClient, parse_build_url
from comparator.connections.azure_devops import version_type
from comparator.runner import RunError, run_build2build

OLD_SHA = "a" * 40
NEW_SHA = "b" * 40

IMAGES = "values/imagesdigest.yaml"
SERVICE_TPL = "values/env/{cluster}/{env}/{service}/{service}.yaml"


def images_yaml(a_version: str, extra: str = "") -> str:
    return (
        "xx-helm-chart:\n  images:\n"
        f"    svc-a:\n      imagePath: repo/svc-a\n      version: {a_version}\n" + extra
    )


def service_yaml(service: str, memory: str, props: str) -> str:
    return (
        "helm-chart:\n  microservices:\n"
        f"    {service}:\n"
        "      replicaCount: 1\n"
        "      resources:\n        limits:\n"
        f"          memory: {memory}\n"
        "      serviceProperties:\n" + props
    )


# What each commit's tree looks like. The new build bumps svc-a's image,
# raises its memory, changes a property, and adds svc-b.
TREES = {
    OLD_SHA: {
        IMAGES: images_yaml("8916368@sha256:aaa"),
        "values/env/ske/sit/svc-a/svc-a.yaml": service_yaml(
            "svc-a", "2G", "        app.timeout=30000\n        app.old-only=yes\n"
        ),
    },
    NEW_SHA: {
        IMAGES: images_yaml(
            "8976368@sha256:bbb",
            "    svc-b:\n      imagePath: repo/svc-b\n      version: 1@sha256:ccc\n",
        ),
        "values/env/ske/sit/svc-a/svc-a.yaml": service_yaml(
            "svc-a", "4G", "        app.timeout=5000\n"
        ),
        "values/env/ske/sit/svc-b/svc-b.yaml": service_yaml(
            "svc-b", "1G", "        app.x=1\n"
        ),
    },
}

BUILDS = {
    "8916368": {
        "id": 8916368,
        "buildNumber": "1.0.25",
        "sourceVersion": OLD_SHA,
        "sourceBranch": "refs/heads/master",
        "definition": {"name": "amazon-payments-CD"},
        "repository": {"name": "DevilsWorld"},
        "finishTime": "2026-07-01T10:00:00Z",
        "result": "succeeded",
    },
    "8976368": {
        "id": 8976368,
        "buildNumber": "1.0.30",
        "sourceVersion": NEW_SHA,
        "sourceBranch": "refs/heads/master",
        "definition": {"name": "amazon-payments-CD"},
        "repository": {"name": "DevilsWorld"},
        "finishTime": "2026-07-15T10:00:00Z",
        "result": "succeeded",
    },
    # Built from a different repo -- its sha means nothing in the chart.
    "999": {
        "id": 999,
        "buildNumber": "9.9.9",
        "sourceVersion": "c" * 40,
        "repository": {"name": "SomeOtherRepo"},
    },
    # No commit at all.
    "888": {"id": 888, "buildNumber": "8.8.8", "sourceVersion": ""},
}


class StubADO(BaseHTTPRequestHandler):
    """Just enough Azure DevOps to answer the two calls we make."""

    seen_item_requests = []

    def log_message(self, *args):
        pass

    def _json(self, payload, code=200):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _text(self, body, code=200):
        raw = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        # Every call must carry Basic auth built from the PAT.
        auth = self.headers.get("Authorization") or ""
        if not auth.startswith("Basic ") or base64.b64decode(
            auth.split(" ", 1)[1]
        ).decode() != ":test-pat":
            return self._json({"message": "unauthorized"}, 401)

        if "/_apis/build/builds/" in parsed.path:
            build_id = parsed.path.rsplit("/", 1)[-1]
            if build_id not in BUILDS:
                return self._json({"message": "not found"}, 404)
            return self._json(BUILDS[build_id])

        # Repo existence. Deliberately no /refs endpoint: Build2Build reads
        # commits, so it must not depend on branch validation.
        if parsed.path.endswith("/_apis/git/repositories/DevilsWorld"):
            return self._json({"name": "DevilsWorld", "id": "repo-guid"})

        if "/_apis/git/repositories/" in parsed.path and parsed.path.endswith("/items"):
            self.__class__.seen_item_requests.append(
                {
                    "path": (qs.get("path") or [""])[0],
                    "version": (qs.get("versionDescriptor.version") or [""])[0],
                    "versionType": (qs.get("versionDescriptor.versionType") or [""])[0],
                }
            )
            sha = (qs.get("versionDescriptor.version") or [""])[0]
            file_path = (qs.get("path") or [""])[0].lstrip("/")
            tree = TREES.get(sha)
            if tree is None or file_path not in tree:
                return self._text("not found", 404)
            return self._text(tree[file_path])

        self._text("not found", 404)


@pytest.fixture
def ado():
    StubADO.seen_item_requests = []
    server = HTTPServer(("127.0.0.1", 0), StubADO)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()


def make_cfg(base_url: str, repository: str = "DevilsWorld") -> Config:
    return Config(
        {
            "connections": {
                "azure_devops": {
                    "mode": "rest",
                    "organization": "myorg",
                    "project": "myproj",
                    "repository": repository,
                    "base_url": base_url,
                    "api_version": "7.1",
                    "pat": "test-pat",
                    "branches": ["master"],
                    "timeout_seconds": 10,
                    "verify_ssl": False,
                }
            },
            "repo_layout": {
                "images_file": IMAGES,
                "service_file": SERVICE_TPL,
                "common_file": "",
                "images_root_key": "xx-helm-chart.images",
                "microservices_root_key": "helm-chart.microservices",
                "service_properties_key": "serviceProperties",
            },
            "target": {"cluster": "ske", "env": "sit", "service_branches": {}, "exclude": []},
            "comparison": {
                "enabled": {"configmap": True, "image": True, "resources": True},
                "configmap": {"include_common": False},
                "image": {"registry": "reg.io", "tolerate_missing_digest": True},
                "resources": {"fields": ["limits.memory"]},
            },
            "report": {},
        }
    )


def url_for(base: str, build_id: str) -> str:
    return f"{base}/myorg/myproj/_build/results?buildId={build_id}&view=results"


# -- URL parsing ----------------------------------------------------------

@pytest.mark.parametrize(
    "url,expected",
    [
        (
            "https://dev.azure.com/myorg/myproj/_build/results?buildId=456",
            ("https://dev.azure.com", "myorg", "myproj", "456"),
        ),
        (
            "https://dev.azure.com/myorg/myproj/_build/results?buildId=456&view=logs",
            ("https://dev.azure.com", "myorg", "myproj", "456"),
        ),
        (
            "https://myorg.visualstudio.com/myproj/_build/results?buildId=99",
            ("https://myorg.visualstudio.com", "myorg", "myproj", "99"),
        ),
        (
            "https://tfs.company.com/tfs/DefaultCollection/myproj/_build/results?buildId=7",
            ("https://tfs.company.com/tfs", "DefaultCollection", "myproj", "7"),
        ),
    ],
)
def test_parse_build_url(url, expected):
    assert parse_build_url(url) == expected


@pytest.mark.parametrize(
    "url,message",
    [
        ("https://dev.azure.com/org/proj/_build?definitionId=12", "buildId"),
        ("https://dev.azure.com/org/proj/_git/repo", "_build"),
        ("not-a-url", "Not a URL"),
        ("", "No pipeline URL"),
        ("https://dev.azure.com/org/proj/_build/results?buildId=abc", "not a number"),
    ],
)
def test_bad_urls_say_why(url, message):
    with pytest.raises(ValueError, match=message):
        parse_build_url(url)


# -- ref handling ---------------------------------------------------------

def test_a_full_sha_is_read_as_a_commit_not_a_branch():
    assert version_type("a" * 40) == "commit"
    assert version_type("master") == "branch"
    assert version_type("release/1.0") == "branch"
    assert version_type("abc123") == "branch"  # too short to be a sha


# -- the build client -----------------------------------------------------

def test_resolves_a_run_to_its_commit(ado):
    client = AdoBuildClient(pat="test-pat")
    build = client.get_build(url_for(ado, "8916368"))
    assert build.commit == OLD_SHA
    assert build.number == "1.0.25"
    assert build.branch == "master"          # refs/heads/ stripped
    assert build.definition == "amazon-payments-CD"
    assert build.label == "Build 1.0.25"


def test_wrong_pat_is_reported_as_a_scope_problem(ado):
    client = AdoBuildClient(pat="wrong")
    with pytest.raises(Exception, match="Build \\(Read\\)"):
        client.get_build(url_for(ado, "8916368"))


def test_missing_build_is_reported(ado):
    client = AdoBuildClient(pat="test-pat")
    with pytest.raises(Exception, match="not found"):
        client.get_build(url_for(ado, "123456"))


def test_build_without_a_commit_is_reported(ado):
    client = AdoBuildClient(pat="test-pat")
    with pytest.raises(Exception, match="no sourceVersion"):
        client.get_build(url_for(ado, "888"))


# -- end to end -----------------------------------------------------------

def test_files_are_fetched_at_each_build_commit(ado):
    run_build2build(make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368"))
    asked = StubADO.seen_item_requests
    assert asked, "no item requests were made"
    # Every read must be pinned to one of the two commits, as a commit.
    assert {r["versionType"] for r in asked} == {"commit"}
    assert {r["version"] for r in asked} == {OLD_SHA, NEW_SHA}


def test_image_bump_between_builds_is_reported(ado):
    report = run_build2build(
        make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368")
    )
    svc = next(s for s in report.services if s.name == "svc-a")
    rows = {d.key: d for a in svc.aspects for d in a.differences}
    assert rows["tag"].left_value == "8916368"
    assert rows["tag"].right_value == "8976368"
    assert rows["digest"].left_value == "sha256:aaa"
    assert rows["digest"].right_value == "sha256:bbb"


def test_property_and_resource_diffs_between_builds(ado):
    report = run_build2build(
        make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368")
    )
    svc = next(s for s in report.services if s.name == "svc-a")
    rows = {d.key: d for a in svc.aspects for d in a.differences}
    assert rows["app.timeout"].left_value == "30000"
    assert rows["app.timeout"].right_value == "5000"
    assert rows["app.old-only"].status.value == "missing_right"
    assert rows["limits.memory"].left_value == "2G"
    assert rows["limits.memory"].right_value == "4G"


def test_service_added_in_the_new_build_is_discovered(ado):
    report = run_build2build(
        make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368")
    )
    svc = next(s for s in report.services if s.name == "svc-b")
    assert svc.left_found is False        # did not exist at the old commit
    assert svc.right_found is True
    assert svc.status.value == "missing_left"


def test_report_is_labelled_with_the_build_numbers(ado):
    report = run_build2build(
        make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368")
    )
    assert report.context["left_label"] == "Build 1.0.25"
    assert report.context["right_label"] == "Build 1.0.30"
    assert "ske/sit" in report.context["title"]


def test_build_from_another_repo_is_refused(ado):
    # Its sha does not exist in the chart repo, so reading it would be nonsense.
    with pytest.raises(RunError, match="SomeOtherRepo"):
        run_build2build(make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "999"))


def test_same_commit_both_sides_is_refused(ado):
    with pytest.raises(RunError, match="same commit"):
        run_build2build(make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8916368"))


def test_local_mode_is_refused_with_a_reason(ado):
    cfg = make_cfg(ado)
    cfg.data["connections"]["azure_devops"]["mode"] = "local"
    with pytest.raises(RunError, match="only works in 'rest' mode"):
        run_build2build(cfg, url_for(ado, "8916368"), url_for(ado, "8976368"))


def test_does_not_require_the_configured_branches_to_exist(ado):
    # The stub serves no /refs endpoint at all. A build's commit says exactly
    # which tree to read, so a stale or deleted `branches:` entry must not
    # fail the run.
    cfg = make_cfg(ado)
    cfg.data["connections"]["azure_devops"]["branches"] = ["a-branch-that-was-deleted"]
    report = run_build2build(cfg, url_for(ado, "8916368"), url_for(ado, "8976368"))
    assert report.services


def test_unknown_repository_is_still_caught(ado):
    cfg = make_cfg(ado, repository="NoSuchRepo")
    with pytest.raises(RunError, match="not found|NoSuchRepo"):
        run_build2build(cfg, url_for(ado, "8916368"), url_for(ado, "8976368"))


def test_a_commit_is_not_reported_as_a_branch(ado):
    # The report's branch chip and "across N branches" summary are about
    # branches; a sha in there would be a lie.
    report = run_build2build(
        make_cfg(ado), url_for(ado, "8916368"), url_for(ado, "8976368")
    )
    assert all(s.branch is None for s in report.services)


def test_branch_pins_do_not_override_a_build_commit(ado):
    # service_branches pins to a branch; a build says exactly which tree to read.
    cfg = make_cfg(ado)
    cfg.data["target"]["service_branches"] = {"svc-a": "some-other-branch"}
    run_build2build(cfg, url_for(ado, "8916368"), url_for(ado, "8976368"))
    assert {r["versionType"] for r in StubADO.seen_item_requests} == {"commit"}
