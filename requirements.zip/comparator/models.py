"""Domain models shared by every source and comparator.

Both sides of a comparison are normalised into a ServiceSnapshot, so
comparators never need to know where the data came from. The sides are only
ever "left" and "right": which systems those are is a label the caller
supplies. That is what lets the same comparators serve both
Azure-DevOps-vs-Kubernetes and folder-vs-folder (sit vs prd).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Side(str, Enum):
    """Which position a snapshot occupies in the comparison."""

    LEFT = "left"
    RIGHT = "right"


class Status(str, Enum):
    """Outcome of comparing a single key."""

    MATCH = "match"
    MISMATCH = "mismatch"
    MISSING_LEFT = "missing_left"
    MISSING_RIGHT = "missing_right"
    WARNING = "warning"


@dataclass
class ImageSpec:
    """A container image, kept in parts so drift can be pinpointed."""

    registry: Optional[str] = None
    path: Optional[str] = None
    tag: Optional[str] = None
    digest: Optional[str] = None
    raw: Optional[str] = None

    @property
    def reference(self) -> str:
        if self.raw:
            return self.raw
        ref = "/".join(p for p in (self.registry, self.path) if p)
        if self.tag:
            ref = f"{ref}:{self.tag}"
        if self.digest:
            ref = f"{ref}@{self.digest}"
        return ref or "-"


@dataclass
class ResourceSpec:
    """Compute resources plus replica count, as flat dotted keys."""

    values: Dict[str, Optional[str]] = field(default_factory=dict)

    def get(self, key: str) -> Optional[str]:
        return self.values.get(key)


@dataclass
class ServiceSnapshot:
    """Everything the comparator knows about one service on one side."""

    name: str
    side: Side
    image: ImageSpec = field(default_factory=ImageSpec)
    resources: ResourceSpec = field(default_factory=ResourceSpec)
    config: Dict[str, str] = field(default_factory=dict)
    # Non-fatal problems hit while reading this service (bad YAML, missing file).
    issues: List[str] = field(default_factory=list)
    # Free-form provenance shown in the report (file path, deployment name, ...).
    origin: Dict[str, Any] = field(default_factory=dict)
    found: bool = True


@dataclass
class Difference:
    """One compared key within one aspect of one service."""

    key: str
    left_value: Optional[str]
    right_value: Optional[str]
    status: Status
    note: Optional[str] = None
    masked: bool = False

    @property
    def is_drift(self) -> bool:
        return self.status not in (Status.MATCH,)


@dataclass
class AspectResult:
    """All differences for one aspect (configmap / image / resources)."""

    aspect: str
    differences: List[Difference] = field(default_factory=list)

    @property
    def drift_count(self) -> int:
        return sum(1 for d in self.differences if d.is_drift)

    @property
    def has_drift(self) -> bool:
        return self.drift_count > 0


@dataclass
class ServiceResult:
    """Comparison outcome for a single service across all aspects."""

    name: str
    aspects: List[AspectResult] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)
    left_found: bool = True
    right_found: bool = True
    # Which branch this service's values were resolved to, when the chart is
    # split across several.
    branch: Optional[str] = None

    @property
    def drift_count(self) -> int:
        return sum(a.drift_count for a in self.aspects)

    @property
    def has_drift(self) -> bool:
        return self.drift_count > 0

    @property
    def status(self) -> Status:
        if not self.left_found:
            return Status.MISSING_LEFT
        if not self.right_found:
            return Status.MISSING_RIGHT
        return Status.MISMATCH if self.has_drift else Status.MATCH


@dataclass
class ComparisonReport:
    """The full run, ready to be rendered."""

    services: List[ServiceResult] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_drift(self) -> int:
        return sum(s.drift_count for s in self.services)

    @property
    def services_with_drift(self) -> int:
        return sum(1 for s in self.services if s.has_drift)
