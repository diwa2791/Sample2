# ⎈ K8s Dashboard

A Spring Boot + Thymeleaf Kubernetes dashboard for **DEV** and **PRD** environments. All data is mocked (no real Kubernetes connection needed). Optimized to handle 140+ services without memory issues.

---

## Quick Start

### Requirements
- Java 17+
- Maven 3.8+

### Run
```bash
cd k8s-dashboard
mvn spring-boot:run
```
Then open: **http://localhost:8080**

### Build JAR
```bash
mvn clean package -DskipTests
java -jar target/k8s-dashboard-1.0.0.jar
```

---

## Features

### DEV Environment (`/dev`)
| Feature | Details |
|---|---|
| **Pod tabs** | Running / Failed / CrashLoopBackOff with counts |
| **Scale** | Click the scale icon → adjust replicas 0–20 |
| **Edit ConfigMap** | Live inline editor, add/remove keys |
| **Edit Deployment** | Image tag, replicas, CPU/memory limits |
| **View Logs** | In-modal log viewer with color-coded levels (INFO/WARN/ERROR) |
| **Download Logs** | Direct `.log` file download per pod |
| **Backup** | Snapshot of all service configs |

### PRD Environment (`/prd`)
| Feature | Details |
|---|---|
| **Backup** | Snapshots replica counts, image tags, configmaps, resource limits |
| **Diff** | Field-by-field diff between any backup and current cluster state |
| **Diff types** | CHANGED (yellow), ADDED (green), REMOVED (red) |

---

## Architecture

```
src/main/java/com/k8sdashboard/
├── K8sDashboardApplication.java     # Entry point
├── controller/
│   ├── HomeController.java          # Redirects / → /dev
│   ├── DevController.java           # DEV pages + REST API
│   └── PrdController.java           # PRD pages + REST API
├── service/
│   └── MockDataService.java         # All mock data (140 services, lazy + cached)
└── model/
    ├── Pod.java
    ├── Deployment.java
    ├── ConfigMap.java
    ├── Backup.java
    ├── DiffResult.java
    └── ApiResponse.java

src/main/resources/
├── templates/
│   ├── dev/index.html               # DEV dashboard
│   ├── prd/index.html               # PRD dashboard
│   └── prd/diff.html                # Diff report page
└── static/
    ├── css/dashboard.css            # Full design system
    └── js/dashboard.js              # Vanilla JS, no framework
```

---

## REST API

### DEV (`/dev/api/`)
| Method | URL | Description |
|---|---|---|
| POST | `/dev/api/pods/{name}/scale?replicas=N` | Scale deployment |
| GET | `/dev/api/pods/{name}/configmap` | Fetch configmap |
| PUT | `/dev/api/pods/{name}/configmap` | Update configmap |
| GET | `/dev/api/pods/{name}/deployment` | Fetch deployment config |
| PUT | `/dev/api/pods/{name}/deployment` | Update deployment config |
| GET | `/dev/api/pods/{name}/logs?lines=N` | Download logs (file) |
| GET | `/dev/api/pods/{name}/logs/view?lines=N` | View logs (JSON) |
| POST | `/dev/api/backup` | Create backup |
| GET | `/dev/api/backups` | List backups |

### PRD (`/prd/api/`)
| Method | URL | Description |
|---|---|---|
| POST | `/prd/api/backup` | Create PRD backup |
| GET | `/prd/api/backups` | List backups |
| GET | `/prd/api/diff/{backupId}` | Get diff (JSON) |
| GET | `/prd/api/pods?page=0&size=20` | Paginated pod list |
| GET | `/prd/api/stats` | Cluster statistics |

---

## Performance Design

| Concern | Solution |
|---|---|
| 140 services × N replicas = large dataset | `ConcurrentHashMap` cache, generated once per env |
| Large DOM with hundreds of pods | Pagination: 20 pods/page, server-side filtering |
| Modal content | Built dynamically, cleared after close |
| No framework bloat | Vanilla JS (~8KB), no React/Vue/Angular |
| Log viewer | Capped at 500 lines max, lazy-loaded in modal |
| Backup list | Capped at 20 entries, auto-trimmed |
| Diff page | Sections collapsed by default, expand on click |
| HTTP compression | Enabled in `application.properties` (gzip) |

---

## Design System

- **Font**: DM Sans (UI) + JetBrains Mono (code/data)  
- **Theme**: Dark industrial (`#0d0f12` base) with sharp color accents  
- **Colors**: Green = running, Red = failed, Yellow = crashloop/changed  
- **No external CSS frameworks** — pure CSS variables + custom design tokens  
