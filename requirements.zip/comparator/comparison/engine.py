"""Orchestrates sources + comparators into a report.

The engine knows nothing about Azure DevOps or Kubernetes: it pairs a *left*
and a *right* source and labels them however the caller asks. That is what
lets the same comparators serve both "branch vs cluster" and "folder vs
folder" without a second implementation.
"""

from __future__ import annotations

import logging
from datetime import datetime
from fnmatch import fnmatch
from typing import Any, Dict, List, Optional

# Importing the module registers the built-in comparators.
from comparator.comparison import comparators  # noqa: F401
from comparator.comparison.registry import get_comparator
from comparator.config import Config
from comparator.models import ComparisonReport, ServiceResult
from comparator.sources.base import SnapshotSource

LOG = logging.getLogger(__name__)


class ComparisonEngine:
    """Pairs each service's two snapshots and runs the enabled comparators."""

    def __init__(
        self,
        left_source: SnapshotSource,
        right_source: SnapshotSource,
        config: Config,
        left_label: str = "Left",
        right_label: str = "Right",
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.left_source = left_source
        self.right_source = right_source
        self.cfg = config
        self.left_label = left_label
        self.right_label = right_label
        self.meta = meta or {}

    @property
    def enabled_aspects(self) -> List[str]:
        enabled = self.cfg.section("comparison.enabled")
        return [name for name, on in enabled.items() if on]

    def discover_services(self) -> List[str]:
        """Every service either side knows about, minus the exclusions.

        The union is deliberate: a service on one side but not the other is
        exactly the drift a hand-maintained list hides. Each shows up as
        missing on its side.
        """
        left = set(self.left_source.list_services())
        right = set(self.right_source.list_services())
        excludes = self.cfg.get("target.exclude") or []
        found = sorted(left | right)
        kept = [s for s in found if not any(fnmatch(s, g) for g in excludes)]

        LOG.info(
            "Discovered %d service(s): %d in %s, %d in %s, %d in both%s",
            len(kept),
            len(left),
            self.left_label,
            len(right),
            self.right_label,
            len(left & right),
            f", {len(found) - len(kept)} excluded" if len(found) != len(kept) else "",
        )
        for name in sorted(left - right):
            LOG.debug("only in %s: %s", self.left_label, name)
        for name in sorted(right - left):
            LOG.debug("only in %s: %s", self.right_label, name)
        return kept

    def run(self, services: List[str]) -> ComparisonReport:
        report = ComparisonReport(context=self._context(services))

        for service in services:
            LOG.info("Comparing %s", service)
            left = self.left_source.snapshot(service)
            right = self.right_source.snapshot(service)

            result = ServiceResult(
                name=service,
                left_found=left.found,
                right_found=right.found,
                branch=left.origin.get("branch") or right.origin.get("branch"),
            )
            result.issues.extend(f"{self.left_label}: {i}" for i in left.issues)
            result.issues.extend(f"{self.right_label}: {i}" for i in right.issues)

            for aspect in self.enabled_aspects:
                try:
                    fn = get_comparator(aspect)
                except KeyError as exc:
                    result.issues.append(str(exc))
                    continue
                try:
                    result.aspects.append(fn(left, right, self.cfg))
                except Exception as exc:  # one bad aspect must not kill the run
                    LOG.exception("Comparator %s failed for %s", aspect, service)
                    result.issues.append(f"comparator {aspect!r} failed: {exc}")

            report.services.append(result)

        return report

    def _context(self, services: List[str]) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {
            "generated_at": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
            "left_label": self.left_label,
            "right_label": self.right_label,
            "services": services,
            "aspects": self.enabled_aspects,
            "title": self.cfg.get("report.title", "Comparison Report"),
        }
        # Mode-specific breadcrumbs (namespace, envs, branches, ...).
        ctx.update(self.meta)
        return ctx
