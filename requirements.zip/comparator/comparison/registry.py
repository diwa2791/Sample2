"""Comparator registry.

New utility features plug in here:

    @register("ingress")
    def compare_ingress(ado, k8s, cfg) -> AspectResult:
        ...

then switch it on under `comparison.enabled` in config.yaml. The engine
discovers comparators by name and never needs editing.
"""

from __future__ import annotations

from typing import Callable, Dict, List

from comparator.config import Config
from comparator.models import AspectResult, ServiceSnapshot

ComparatorFn = Callable[[ServiceSnapshot, ServiceSnapshot, Config], AspectResult]

_REGISTRY: Dict[str, ComparatorFn] = {}


def register(name: str) -> Callable[[ComparatorFn], ComparatorFn]:
    def decorator(fn: ComparatorFn) -> ComparatorFn:
        _REGISTRY[name] = fn
        return fn

    return decorator


def get_comparator(name: str) -> ComparatorFn:
    if name not in _REGISTRY:
        raise KeyError(
            f"No comparator registered as {name!r}. Available: {', '.join(available())}"
        )
    return _REGISTRY[name]


def available() -> List[str]:
    return sorted(_REGISTRY)
