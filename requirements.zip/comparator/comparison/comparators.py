"""The built-in comparators: configmap, image, resources.

Each takes the two snapshots plus config and returns an AspectResult. They are
registered by name so config decides which ones run.
"""

from __future__ import annotations

from fnmatch import fnmatch
from typing import List, Optional

from comparator.comparison.normalizers import normalise_resource
from comparator.comparison.registry import register
from comparator.config import Config
from comparator.models import AspectResult, Difference, ServiceSnapshot, Status

MASK = "********"


def _matches_any(key: str, globs: List[str]) -> bool:
    lowered = key.lower()
    return any(fnmatch(lowered, g.lower()) for g in globs or [])


def _status_for(ado: Optional[str], k8s: Optional[str]) -> Status:
    if ado is None and k8s is None:
        return Status.MATCH
    if ado is None:
        return Status.MISSING_LEFT
    if k8s is None:
        return Status.MISSING_RIGHT
    return Status.MATCH if ado == k8s else Status.MISMATCH


@register("configmap")
def compare_configmap(
    ado: ServiceSnapshot, k8s: ServiceSnapshot, cfg: Config
) -> AspectResult:
    section = cfg.section("comparison.configmap")
    ignore = section.get("ignore_key_globs") or []
    mask = section.get("mask_value_globs") or []

    result = AspectResult(aspect="configmap")
    keys = sorted(set(ado.config) | set(k8s.config))
    for key in keys:
        if _matches_any(key, ignore):
            continue
        left_value = ado.config.get(key)
        right_value = k8s.config.get(key)
        status = _status_for(left_value, right_value)
        masked = _matches_any(key, mask)
        result.differences.append(
            Difference(
                key=key,
                left_value=MASK if (masked and left_value is not None) else left_value,
                right_value=MASK if (masked and right_value is not None) else right_value,
                status=status,
                masked=masked,
                note="value masked by policy" if masked else None,
            )
        )
    return result


@register("image")
def compare_image(
    ado: ServiceSnapshot, k8s: ServiceSnapshot, cfg: Config
) -> AspectResult:
    section = cfg.section("comparison.image")
    digest_only = bool(section.get("compare_digest_only", False))
    tolerate_missing = bool(section.get("tolerate_missing_digest", True))

    result = AspectResult(aspect="image")

    def add(key: str, left_value: Optional[str], right_value: Optional[str], note: str = None) -> None:
        result.differences.append(
            Difference(
                key=key,
                left_value=left_value,
                right_value=right_value,
                status=_status_for(left_value, right_value),
                note=note,
            )
        )

    # Digest is the only unambiguous identity of an image.
    ado_digest, k8s_digest = ado.image.digest, k8s.image.digest
    if ado_digest is None or k8s_digest is None:
        status = Status.WARNING if tolerate_missing else _status_for(ado_digest, k8s_digest)
        result.differences.append(
            Difference(
                key="digest",
                left_value=ado_digest,
                right_value=k8s_digest,
                status=status,
                note="digest absent on one side; cannot prove images are identical",
            )
        )
    else:
        add("digest", ado_digest, k8s_digest)

    if not digest_only:
        add("path", ado.image.path, k8s.image.path)
        add("tag", ado.image.tag, k8s.image.tag)
        add(
            "reference",
            ado.image.reference,
            k8s.image.reference,
            note="full reference as declared vs running",
        )

    return result


@register("resources")
def compare_resources(
    ado: ServiceSnapshot, k8s: ServiceSnapshot, cfg: Config
) -> AspectResult:
    fields = cfg.get("comparison.resources.fields") or [
        "requests.memory",
        "requests.cpu",
        "limits.memory",
        "limits.cpu",
        "replicaCount",
    ]

    result = AspectResult(aspect="resources")
    for key in fields:
        ado_raw = ado.resources.get(key)
        k8s_raw = k8s.resources.get(key)
        ado_norm = normalise_resource(key, ado_raw)
        k8s_norm = normalise_resource(key, k8s_raw)
        status = _status_for(ado_norm, k8s_norm)
        note = None
        # Show that equality came from normalisation, not identical text.
        if status is Status.MATCH and ado_raw != k8s_raw and ado_raw and k8s_raw:
            note = "equivalent after normalisation"
        result.differences.append(
            Difference(
                key=key,
                left_value=ado_raw,
                right_value=k8s_raw,
                status=status,
                note=note,
            )
        )
    return result
