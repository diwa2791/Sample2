#!/usr/bin/env python
"""Kube2Branch -- compare Azure DevOps helm values against live Kubernetes.

RUN THIS FILE. No install step, no `pip install -e .`, no `python -m`.

    python main.py                     compare everything -> HTML report
    python main.py --open              ...and open it in the browser
    python main.py --drift-only        hide rows that match
    python main.py --services aa-flip-owd01
    python main.py check               just test the two connections
    python main.py config              edit config.yaml in a local web UI
    python main.py list-comparators    show the registered checks

Everything is configured in config/config.yaml -- by hand, or through
`python main.py config`.

`comparator/` sits next to this file, so Python finds it automatically --
open the folder in your IDE, edit anything under comparator/, and run this
file again. There is nothing to rebuild.
"""

from __future__ import annotations

import sys

# The subcommands cli.py understands. Anything else means the user went
# straight for the common case, so `python main.py --open` is treated as
# `python main.py compare --open`.
COMMANDS = (
    "compare", "folders", "builds", "check", "list-comparators", "config", "ui",
)

DEPENDENCIES = {
    "yaml": "PyYAML",
    "requests": "requests",
    "jinja2": "Jinja2",
    "kubernetes": "kubernetes",
}


def check_dependencies() -> None:
    """Fail with the fix, not a stack trace, when the deps are not installed."""
    missing = []
    for module, package in DEPENDENCIES.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    if missing:
        sys.exit(
            "Missing required package(s): {}\n\n"
            "Install them with:\n"
            "    {} -m pip install -r requirements.txt".format(
                ", ".join(missing), sys.executable
            )
        )


def main() -> int:
    check_dependencies()

    # Imported after the dependency check so a missing package reports the
    # message above rather than an ImportError from deep inside the package.
    from comparator.cli import main as cli_main

    argv = sys.argv[1:]
    # `python main.py --open` should mean `compare --open`, but a global option
    # may legitimately precede the subcommand (`-c other.yaml config`), so look
    # for a command anywhere rather than only in first position.
    has_command = any(a in COMMANDS for a in argv)
    wants_help = any(a in ("-h", "--help") for a in argv)
    if not has_command and not wants_help:
        argv = ["compare"] + argv
    return cli_main(argv)


if __name__ == "__main__":
    sys.exit(main())
