package com.k8sdashboard.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@Getter
@Setter
public class Backup {
    private String id;
    private String environment;  // DEV or PRD
    private LocalDateTime createdAt;
    private String createdBy;
    private BackupStatus status;
    private List<BackupEntry> entries;
    private String notes;

    public enum BackupStatus {
        COMPLETED, IN_PROGRESS, FAILED
    }

    @Data
    @Builder
    @Getter
    @Setter
    public static class BackupEntry {
        private String serviceName;
        private String namespace;
        private int replicaCount;
        private String image;
        private String imageTag;
        private Map<String, String> configMapData;
        private String cpuRequest;
        private String cpuLimit;
        private String memoryRequest;
        private String memoryLimit;
    }
}
