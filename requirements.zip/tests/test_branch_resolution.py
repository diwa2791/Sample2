"""Resolving which branch owns a service, when the chart is split across many.

Mirrors the real shape: services spread over branch1/branch2/branch3, each
branch's images file declaring only the services it owns.
"""

from typing import Dict, List, Optional

import pytest

from comparator.config import Config
from comparator.connections.azure_devops import resolve_branches
from comparator.sources.ado import AdoSource

IMAGES = "chart/values/imagesdigest.yaml"
SERVICE = "chart/values/{service}/{service}.yaml"


def images_yaml(*services: str) -> str:
    body = "\n".join(
        f"    {s}:\n      imagePath: repo/{s}\n      version: 111@sha256:{s}" for s in services
    )
    return f"xx-helm-chart:\n  images:\n{body}\n"


def service_yaml(service: str) -> str:
    return (
        "helm-chart:\n"
        "  microservices:\n"
        f"    {service}:\n"
        "      replicaCount: 1\n"
        "      serviceProperties:\n"
        "        a=1\n"
    )


class FakeRepo:
    """A repo whose files exist only on specific branches. Counts reads so the
    tests can assert the resolution cost, not just its answer."""

    def __init__(self, files: Dict[str, Dict[str, str]]) -> None:
        # files: {branch: {path: text}}
        self.files = files
        self.reads: List[tuple] = []

    @property
    def refs(self) -> List[str]:
        return list(self.files)

    def read_text(self, path: str, ref: Optional[str] = None) -> str:
        ref = ref or self.refs[0]
        self.reads.append((path, ref))
        try:
            return self.files[ref][path]
        except KeyError:
            raise FileNotFoundError(f"{path}@{ref}")

    def describe(self, path: str, ref: Optional[str] = None) -> str:
        return f"{ref}:{path}"


def make_config() -> Config:
    return Config(
        {
            "repo_layout": {
                "images_file": IMAGES,
                "service_file": SERVICE,
                "common_file": "",
                "images_root_key": "xx-helm-chart.images",
                "microservices_root_key": "helm-chart.microservices",
                "service_properties_key": "serviceProperties",
            },
            "target": {"cluster": "ske", "env": "sit", "service_branches": {}},
            "comparison": {"configmap": {"include_common": False}, "image": {}},
        }
    )


def three_branches() -> FakeRepo:
    return FakeRepo(
        {
            "branch1": {
                IMAGES: images_yaml("svc-a"),
                "chart/values/svc-a/svc-a.yaml": service_yaml("svc-a"),
            },
            "branch2": {
                IMAGES: images_yaml("svc-b"),
                "chart/values/svc-b/svc-b.yaml": service_yaml("svc-b"),
            },
            "branch3": {
                IMAGES: images_yaml("svc-c"),
                "chart/values/svc-c/svc-c.yaml": service_yaml("svc-c"),
            },
        }
    )


def test_each_service_resolves_to_its_own_branch():
    src = AdoSource(three_branches(), make_config())
    assert src.snapshot("svc-a").origin["branch"] == "branch1"
    assert src.snapshot("svc-b").origin["branch"] == "branch2"
    assert src.snapshot("svc-c").origin["branch"] == "branch3"


def test_resolution_does_not_probe_every_branch_per_service():
    # The images index exists so cost stays ~1 values read per service rather
    # than one per branch per service (140 x 3 = 420 requests at real scale).
    repo = three_branches()
    src = AdoSource(repo, make_config())
    src.snapshot("svc-c")
    values_reads = [r for r in repo.reads if r[0] != IMAGES]
    assert values_reads == [("chart/values/svc-c/svc-c.yaml", "branch3")]


def test_images_files_are_read_once_per_branch_not_per_service():
    repo = three_branches()
    src = AdoSource(repo, make_config())
    for svc in ("svc-a", "svc-b", "svc-c"):
        src.snapshot(svc)
    images_reads = [r for r in repo.reads if r[0] == IMAGES]
    assert sorted(images_reads) == [(IMAGES, "branch1"), (IMAGES, "branch2"), (IMAGES, "branch3")]


def test_service_on_no_branch_is_reported_not_crashed():
    src = AdoSource(three_branches(), make_config())
    snap = src.snapshot("svc-missing")
    assert snap.found is False
    assert any("no values file on any configured branch" in i for i in snap.issues)


def test_service_defined_on_two_branches_is_flagged():
    repo = three_branches()
    # svc-a also leaks into branch2 -- ambiguous ownership.
    repo.files["branch2"]["chart/values/svc-a/svc-a.yaml"] = service_yaml("svc-a")
    repo.files["branch2"][IMAGES] = images_yaml("svc-b", "svc-a")
    src = AdoSource(repo, make_config())
    snap = src.snapshot("svc-a")
    assert snap.origin["branch"] == "branch1"
    assert any("multiple branches" in i for i in snap.issues)


def test_values_file_wins_when_images_hint_is_wrong():
    repo = three_branches()
    # branch1 claims svc-c in its images file, but the values file is on branch3.
    repo.files["branch1"][IMAGES] = images_yaml("svc-a", "svc-c")
    src = AdoSource(repo, make_config())
    snap = src.snapshot("svc-c")
    assert snap.origin["branch"] == "branch3"


def test_explicit_pin_skips_discovery():
    repo = three_branches()
    cfg = make_config()
    cfg.data["target"]["service_branches"] = {"svc-b": "branch2"}
    src = AdoSource(repo, cfg)
    assert src.snapshot("svc-b").origin["branch"] == "branch2"
    # A pin means we never consult the index at all.
    assert not [r for r in repo.reads if r[0] == IMAGES and r[1] == "branch1"]


def test_single_branch_repo_still_works():
    repo = FakeRepo(
        {
            "master": {
                IMAGES: images_yaml("svc-a"),
                "chart/values/svc-a/svc-a.yaml": service_yaml("svc-a"),
            }
        }
    )
    src = AdoSource(repo, make_config())
    snap = src.snapshot("svc-a")
    assert snap.origin["branch"] == "master"
    assert snap.image.digest == "sha256:svc-a"


@pytest.mark.parametrize(
    "section,expected",
    [
        ({"branches": ["b1", "b2"], "branch": "master"}, ["b1", "b2"]),
        ({"branches": [], "branch": "master"}, ["master"]),
        ({"branches": "b1, b2", "branch": "master"}, ["b1", "b2"]),
        ({"branches": "", "branch": ""}, []),
        ({"branch": "master"}, ["master"]),
    ],
)
def test_resolve_branches_accepts_list_csv_or_single(section, expected):
    assert resolve_branches(section) == expected
