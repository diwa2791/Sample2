package com.k8sdashboard.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@Getter
@Setter
public class ConfigMap {
    private String name;
    private String namespace;
    private Map<String, String> data;
    private String createdAt;
}
