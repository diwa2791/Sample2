"""Folder-vs-folder: same chart, same branch, two env folders."""

import pytest

from comparator.config import Config
from comparator.models import Side
from comparator.runner import RunError, run_folder2folder
from comparator.sources.ado import AdoSource

IMAGES = "values/imagesdigest.yaml"
SERVICE = "values/env/{cluster}/{env}/{service}/{service}.yaml"


def service_yaml(service: str, memory: str, replicas: int, props: str) -> str:
    return (
        "helm-chart:\n"
        "  microservices:\n"
        f"    {service}:\n"
        f"      replicaCount: {replicas}\n"
        "      resources:\n"
        "        limits:\n"
        f"          memory: {memory}\n"
        "      serviceProperties:\n" + props
    )


class FakeRepo:
    def __init__(self, files):
        self.files = files

    @property
    def refs(self):
        return ["master"]

    def read_text(self, path, ref=None):
        try:
            return self.files[path]
        except KeyError:
            raise FileNotFoundError(path)

    def describe(self, path, ref=None):
        return path

    def check(self, verify_branches=True):
        return {"mode": "fake"}


def make_cfg():
    return Config(
        {
            "repo_layout": {
                "images_file": IMAGES,
                "service_file": SERVICE,
                "common_file": "",
                "images_root_key": "xx-helm-chart.images",
                "microservices_root_key": "helm-chart.microservices",
                "service_properties_key": "serviceProperties",
            },
            "target": {"cluster": "ske", "env": "sit", "service_branches": {}, "exclude": []},
            "comparison": {
                "enabled": {"configmap": True, "resources": True},
                "configmap": {"include_common": False},
                "image": {},
                "resources": {"fields": ["limits.memory", "replicaCount"]},
            },
            "report": {},
        }
    )


def repo():
    return FakeRepo(
        {
            IMAGES: (
                "xx-helm-chart:\n  images:\n"
                "    svc-a:\n      imagePath: repo/svc-a\n      version: 1@sha256:aaa\n"
                "    svc-b:\n      imagePath: repo/svc-b\n      version: 1@sha256:bbb\n"
            ),
            "values/env/ske/sit/svc-a/svc-a.yaml": service_yaml(
                "svc-a", "2G", 1, "        app.timeout=30000\n        app.debug=true\n"
            ),
            "values/env/ske/prd/svc-a/svc-a.yaml": service_yaml(
                "svc-a", "4G", 4, "        app.timeout=5000\n        app.prd-only=yes\n"
            ),
            # svc-b exists in sit but was never promoted to prd.
            "values/env/ske/sit/svc-b/svc-b.yaml": service_yaml(
                "svc-b", "1G", 1, "        app.x=1\n"
            ),
        }
    )


def test_two_envs_read_two_different_folders():
    cfg = make_cfg()
    conn = repo()
    sit = AdoSource(conn, cfg, cluster="ske", env="sit")
    prd = AdoSource(conn, cfg, cluster="ske", env="prd")
    assert sit.snapshot("svc-a").resources.get("limits.memory") == "2G"
    assert prd.snapshot("svc-a").resources.get("limits.memory") == "4G"


def test_env_override_does_not_leak_between_instances():
    cfg = make_cfg()
    conn = repo()
    prd = AdoSource(conn, cfg, env="prd")
    sit = AdoSource(conn, cfg)  # falls back to target.env
    assert prd.env == "prd"
    assert sit.env == "sit"


@pytest.fixture
def cfg(monkeypatch):
    """Config wired to the fake repo, undone after each test.

    monkeypatch rather than a module-level assignment: patching
    runner.build_repo_connection permanently would leak into every other test
    in the session.
    """
    conn = repo()
    monkeypatch.setattr(
        "comparator.runner.build_repo_connection", lambda _cfg: conn
    )
    return make_cfg()


def test_report_is_labelled_with_the_two_envs(cfg):
    report = run_folder2folder(cfg, "sit", "prd")
    assert report.context["left_label"] == "sit"
    assert report.context["right_label"] == "prd"
    assert "sit vs prd" in report.context["title"]


def test_value_drift_between_envs_is_reported(cfg):
    report = run_folder2folder(cfg, "sit", "prd")
    svc = next(s for s in report.services if s.name == "svc-a")
    rows = {d.key: d for a in svc.aspects for d in a.differences}

    assert rows["limits.memory"].left_value == "2G"
    assert rows["limits.memory"].right_value == "4G"
    assert rows["limits.memory"].status.value == "mismatch"

    assert rows["replicaCount"].left_value == "1"
    assert rows["replicaCount"].right_value == "4"

    assert rows["app.timeout"].left_value == "30000"
    assert rows["app.timeout"].right_value == "5000"


def test_key_only_in_one_env_is_missing_from_the_other(cfg):
    report = run_folder2folder(cfg, "sit", "prd")
    svc = next(s for s in report.services if s.name == "svc-a")
    rows = {d.key: d for a in svc.aspects for d in a.differences}
    assert rows["app.prd-only"].status.value == "missing_left"   # not in sit
    assert rows["app.debug"].status.value == "missing_right"     # not in prd


def test_service_not_promoted_to_prd_is_reported_missing(cfg):
    report = run_folder2folder(cfg, "sit", "prd")
    svc = next(s for s in report.services if s.name == "svc-b")
    assert svc.left_found is True
    assert svc.right_found is False
    assert svc.status.value == "missing_right"


def test_swapping_the_sides_swaps_the_labels_and_values(cfg):
    report = run_folder2folder(cfg, "prd", "sit")
    assert report.context["left_label"] == "prd"
    svc = next(s for s in report.services if s.name == "svc-a")
    rows = {d.key: d for a in svc.aspects for d in a.differences}
    assert rows["limits.memory"].left_value == "4G"
    assert rows["limits.memory"].right_value == "2G"


def test_comparing_a_folder_with_itself_is_refused(cfg):
    with pytest.raises(RunError, match="both sides are"):
        run_folder2folder(cfg, "sit", "sit")


def test_missing_folder_name_is_refused(cfg):
    with pytest.raises(RunError, match="Both folders"):
        run_folder2folder(cfg, "sit", "")


def test_sources_are_labelled_left_and_right():
    assert AdoSource(repo(), make_cfg()).side is Side.LEFT
