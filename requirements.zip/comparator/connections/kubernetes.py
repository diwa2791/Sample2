"""Kubernetes cluster access.

Wraps client construction (kubeconfig vs in-cluster) and exposes only the
read calls the comparator needs.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from comparator.config import Config
from comparator.connections.base import Connection, ConnectionError_


class KubernetesConnection(Connection):
    """Read-only access to deployments and configmaps in one namespace."""

    name = "kubernetes"

    def __init__(
        self,
        mode: str = "kubeconfig",
        kubeconfig_path: Optional[str] = None,
        context: Optional[str] = None,
        namespace: str = "default",
        timeout_seconds: int = 30,
    ) -> None:
        self.mode = (mode or "kubeconfig").strip().lower()
        self.kubeconfig_path = kubeconfig_path or None
        self.context = context or None
        self.namespace = namespace
        self.timeout = timeout_seconds
        self._apps = None
        self._core = None

    def _ensure_clients(self) -> None:
        if self._apps is not None:
            return
        try:
            from kubernetes import client, config as k8s_config
        except ImportError as exc:  # pragma: no cover
            raise ConnectionError_(
                "The 'kubernetes' package is not installed. pip install -r requirements.txt"
            ) from exc

        try:
            if self.mode == "in_cluster":
                k8s_config.load_incluster_config()
            elif self.mode == "kubeconfig":
                k8s_config.load_kube_config(
                    config_file=self.kubeconfig_path, context=self.context
                )
            else:
                raise ValueError(
                    f"Unknown kubernetes mode {self.mode!r}. Expected 'kubeconfig' or 'in_cluster'."
                )
        except Exception as exc:
            raise ConnectionError_(f"Could not load kube config: {exc}") from exc

        self._apps = client.AppsV1Api()
        self._core = client.CoreV1Api()

    def check(self) -> Dict[str, Any]:
        self._ensure_clients()
        try:
            self._core.read_namespace(self.namespace, _request_timeout=self.timeout)
        except Exception as exc:
            raise ConnectionError_(
                f"Cannot read namespace {self.namespace!r}: {exc}"
            ) from exc
        return {
            "mode": self.mode,
            "context": self.context or "(current)",
            "namespace": self.namespace,
        }

    def get_deployment(self, name: str) -> Optional[Any]:
        """Return the Deployment object, or None when it does not exist."""
        self._ensure_clients()
        try:
            return self._apps.read_namespaced_deployment(
                name=name, namespace=self.namespace, _request_timeout=self.timeout
            )
        except Exception as exc:
            if getattr(exc, "status", None) == 404:
                return None
            raise ConnectionError_(f"Failed to read deployment {name}: {exc}") from exc

    def get_configmap(self, name: str) -> Optional[Any]:
        """Return the ConfigMap object, or None when it does not exist."""
        self._ensure_clients()
        try:
            return self._core.read_namespaced_config_map(
                name=name, namespace=self.namespace, _request_timeout=self.timeout
            )
        except Exception as exc:
            if getattr(exc, "status", None) == 404:
                return None
            raise ConnectionError_(f"Failed to read configmap {name}: {exc}") from exc

    def list_deployment_names(self) -> List[str]:
        self._ensure_clients()
        try:
            items = self._apps.list_namespaced_deployment(
                namespace=self.namespace, _request_timeout=self.timeout
            ).items
        except Exception as exc:
            raise ConnectionError_(f"Failed to list deployments: {exc}") from exc
        return [d.metadata.name for d in items]

    @classmethod
    def from_config(cls, config: Config) -> "KubernetesConnection":
        section = config.section("connections.kubernetes")
        return cls(
            mode=section.get("mode", "kubeconfig"),
            kubeconfig_path=section.get("kubeconfig_path") or None,
            context=section.get("context") or None,
            namespace=section.get("namespace", "default"),
            timeout_seconds=int(section.get("timeout_seconds", 30)),
        )
