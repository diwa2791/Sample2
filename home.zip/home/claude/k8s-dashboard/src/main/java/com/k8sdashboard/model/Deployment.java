package com.k8sdashboard.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@Getter
@Setter
public class Deployment {
    private String name;
    private String namespace;
    private int replicas;
    private int availableReplicas;
    private int readyReplicas;
    private String image;
    private String imageTag;
    private Map<String, String> envVars;
    private ResourceConfig resources;
    private String strategy;
    private Map<String, String> labels;
    private Map<String, String> annotations;

    @Data
    @Builder
    @Getter
    @Setter
    public static class ResourceConfig {
        private String cpuRequest;
        private String cpuLimit;
        private String memoryRequest;
        private String memoryLimit;
    }

    public String getFullImage() {
        return image + ":" + imageTag;
    }
}
