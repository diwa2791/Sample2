"""Azure DevOps repo access.

Two interchangeable implementations behind one interface:

  rest  -> Azure DevOps Repos "Items" REST API (the real source of truth)
  local -> a local checkout of the same repo (offline dev, CI pre-clone, tests)

Both are multi-ref: a chart's services may be split across several branches
(e.g. 140 services over branch1/branch2/branch3). The connection only knows
how to read a path *from a given ref*; deciding which ref owns a service is
the source layer's job.

build_repo_connection() picks one from config, so callers never branch on mode.
"""

from __future__ import annotations

import base64
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from comparator.config import Config
from comparator.connections.base import ConnectionError_, RepoConnection

LOCAL_REF = "local"

# Azure DevOps hands back full 40-char shas, and branch names are never that,
# so a ref is a commit iff it looks exactly like one. Build2Build reads at a
# commit; everything else reads at a branch.
_SHA_RE = re.compile(r"^[0-9a-f]{40}$")


def version_type(ref: str) -> str:
    """'commit' for a full sha, otherwise 'branch'."""
    return "commit" if _SHA_RE.match(ref or "") else "branch"


class AzureDevOpsConnection(RepoConnection):
    """Reads files from Azure DevOps Repos over HTTPS using a PAT."""

    name = "azure_devops:rest"

    def __init__(
        self,
        organization: str,
        project: str,
        repository: str,
        pat: str,
        branches: Optional[List[str]] = None,
        base_url: str = "https://dev.azure.com",
        api_version: str = "7.1",
        timeout_seconds: int = 30,
        verify_ssl: bool = True,
    ) -> None:
        if not pat:
            raise ConnectionError_(
                "Azure DevOps PAT is empty. Set ADO_PAT, or use ADO_MODE=local."
            )
        self.organization = organization
        self.project = project
        self.repository = repository
        self._branches = [b for b in (branches or []) if b]
        if not self._branches:
            raise ValueError("At least one Azure DevOps branch must be configured.")
        self.base_url = base_url.rstrip("/")
        self.api_version = api_version
        self.timeout = timeout_seconds
        self._session = requests.Session()
        self._session.verify = verify_ssl
        # Azure DevOps expects Basic auth with an empty username.
        token = base64.b64encode(f":{pat}".encode()).decode()
        self._session.headers.update(
            {"Authorization": f"Basic {token}", "Accept": "text/plain"}
        )

    @property
    def refs(self) -> List[str]:
        return list(self._branches)

    def _ref(self, ref: Optional[str]) -> str:
        return ref or self._branches[0]

    @property
    def _items_url(self) -> str:
        return (
            f"{self.base_url}/{self.organization}/{self.project}"
            f"/_apis/git/repositories/{self.repository}/items"
        )

    def _params(self, path: str, ref: str) -> Dict[str, str]:
        return {
            "path": path,
            "versionDescriptor.version": ref,
            "versionDescriptor.versionType": version_type(ref),
            "includeContent": "true",
            "$format": "text",
            "api-version": self.api_version,
        }

    def read_text(self, path: str, ref: Optional[str] = None) -> str:
        branch = self._ref(ref)
        try:
            resp = self._session.get(
                self._items_url, params=self._params(path, branch), timeout=self.timeout
            )
        except requests.RequestException as exc:
            raise ConnectionError_(f"Azure DevOps request failed: {exc}") from exc

        if resp.status_code == 404:
            raise FileNotFoundError(
                f"Not found in {self.repository}@{branch}: {path}"
            )
        if resp.status_code in (401, 203):
            # ADO returns 203 + a sign-in page when the PAT is invalid.
            raise ConnectionError_(
                "Azure DevOps rejected the PAT (401/203). Check ADO_PAT scope: Code (Read)."
            )
        if not resp.ok:
            raise ConnectionError_(
                f"Azure DevOps returned {resp.status_code} for {path}@{branch}: {resp.text[:200]}"
            )
        return resp.text

    def describe(self, path: str, ref: Optional[str] = None) -> str:
        target = self._ref(ref)
        # GB = branch, GC = commit, in Azure DevOps' own URL vocabulary.
        prefix = "GC" if version_type(target) == "commit" else "GB"
        return (
            f"{self.base_url}/{self.organization}/{self.project}/_git/"
            f"{self.repository}?path={path}&version={prefix}{target}"
        )

    def _branch_exists(self, branch: str) -> bool:
        url = (
            f"{self.base_url}/{self.organization}/{self.project}"
            f"/_apis/git/repositories/{self.repository}/refs"
        )
        try:
            resp = self._session.get(
                url,
                params={"filter": f"heads/{branch}", "api-version": self.api_version},
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise ConnectionError_(f"Azure DevOps unreachable: {exc}") from exc
        if not resp.ok:
            raise ConnectionError_(
                f"Azure DevOps refs check failed ({resp.status_code}) on {self.repository}"
            )
        try:
            return bool((resp.json() or {}).get("count"))
        except ValueError:
            return False

    def _repo_exists(self) -> bool:
        url = (
            f"{self.base_url}/{self.organization}/{self.project}"
            f"/_apis/git/repositories/{self.repository}"
        )
        try:
            resp = self._session.get(
                url, params={"api-version": self.api_version}, timeout=self.timeout
            )
        except requests.RequestException as exc:
            raise ConnectionError_(f"Azure DevOps unreachable: {exc}") from exc
        if resp.status_code == 404:
            return False
        if resp.status_code in (401, 203):
            raise ConnectionError_(
                "Azure DevOps rejected the PAT (401/203). Check ADO_PAT scope: Code (Read)."
            )
        return resp.ok

    def check(self, verify_branches: bool = True) -> Dict[str, Any]:
        """`verify_branches` is skipped when the caller reads commits.

        Build2Build pins each side to a build's sourceVersion, so whether the
        branches listed in config still exist has no bearing on the run --
        failing it on that would be a false alarm.
        """
        if not self._repo_exists():
            raise ConnectionError_(
                f"Repository {self.repository!r} not found in "
                f"{self.organization}/{self.project}."
            )
        details: Dict[str, Any] = {
            "mode": "rest",
            "organization": self.organization,
            "project": self.project,
            "repository": self.repository,
        }
        if verify_branches:
            missing = [b for b in self._branches if not self._branch_exists(b)]
            if missing:
                raise ConnectionError_(
                    f"Branch(es) not found in {self.repository}: {', '.join(missing)}"
                )
            details["branches"] = self._branches
        return details


class LocalRepoConnection(RepoConnection):
    """Reads the same repo layout from local directories.

    With `branch_roots` it models several checked-out branches at once (one
    directory per branch); without it there is a single root and the ref is
    ignored, which is the ordinary offline case.
    """

    name = "azure_devops:local"

    def __init__(
        self,
        root_path: str,
        branch_roots: Optional[Dict[str, str]] = None,
    ) -> None:
        self.root = Path(root_path).resolve() if root_path else None
        self.branch_roots = {
            branch: Path(p).resolve() for branch, p in (branch_roots or {}).items() if p
        }

    @property
    def refs(self) -> List[str]:
        return list(self.branch_roots) or [LOCAL_REF]

    def _root_for(self, ref: Optional[str]) -> Path:
        if self.branch_roots:
            key = ref if ref in self.branch_roots else self.refs[0]
            return self.branch_roots[key]
        if self.root is None:
            raise ConnectionError_("No local root configured.")
        return self.root

    def _resolve(self, path: str, ref: Optional[str] = None) -> Path:
        root = self._root_for(ref)
        candidate = (root / path).resolve()
        # Guard against path templates escaping the configured root.
        if not str(candidate).startswith(str(root)):
            raise ConnectionError_(f"Path escapes repo root: {path}")
        return candidate

    def read_text(self, path: str, ref: Optional[str] = None) -> str:
        target = self._resolve(path, ref)
        if not target.is_file():
            raise FileNotFoundError(f"Not found under {self._root_for(ref)}: {path}")
        return target.read_text(encoding="utf-8")

    def describe(self, path: str, ref: Optional[str] = None) -> str:
        return str(self._resolve(path, ref))

    def check(self, verify_branches: bool = True) -> Dict[str, Any]:
        if self.branch_roots:
            missing = [b for b, p in self.branch_roots.items() if not p.is_dir()]
            if missing:
                raise ConnectionError_(
                    f"Local root missing for branch(es): {', '.join(missing)}"
                )
            return {
                "mode": "local",
                "branch_roots": {b: str(p) for b, p in self.branch_roots.items()},
            }
        if self.root is None or not self.root.is_dir():
            raise ConnectionError_(f"Local repo root does not exist: {self.root}")
        return {"mode": "local", "root": str(self.root)}


def resolve_branches(section: Dict[str, Any]) -> List[str]:
    """Config may name one branch or several; normalise to a list.

    `branches` wins when present; `branch` remains the single-branch spelling.
    """
    branches = section.get("branches") or []
    if isinstance(branches, str):
        branches = [b.strip() for b in branches.split(",")]
    branches = [str(b).strip() for b in branches if str(b).strip()]
    if branches:
        return branches
    single = str(section.get("branch") or "").strip()
    return [single] if single else []


def _anchor(path_value: str, config: Config) -> str:
    """Resolve a relative local path against the repo root, not the cwd.

    Config ships `../DevilsWorld` so a fresh clone works unedited; anchoring it
    to the config file's location means it keeps working no matter where the
    command is run from.
    """
    candidate = Path(path_value)
    if candidate.is_absolute():
        return str(candidate)
    base = config.path.parent.parent if config.path else Path.cwd()
    return str((base / candidate).resolve())


def build_repo_connection(config: Config) -> RepoConnection:
    """Instantiate the repo connection named by connections.azure_devops.mode."""
    section = config.section("connections.azure_devops")
    mode = (section.get("mode") or "local").strip().lower()

    if mode == "local":
        return LocalRepoConnection(
            root_path=_anchor(section.get("root_path") or ".", config),
            branch_roots={
                branch: _anchor(p, config)
                for branch, p in (section.get("branch_roots") or {}).items()
                if p
            },
        )
    if mode == "rest":
        branches = resolve_branches(section)
        if not branches:
            raise ValueError(
                "No Azure DevOps branch configured. Set connections.azure_devops.branches."
            )
        return AzureDevOpsConnection(
            organization=section.get("organization", ""),
            project=section.get("project", ""),
            repository=section.get("repository", ""),
            pat=section.get("pat", ""),
            branches=branches,
            base_url=section.get("base_url", "https://dev.azure.com"),
            api_version=str(section.get("api_version", "7.1")),
            timeout_seconds=int(section.get("timeout_seconds", 30)),
            verify_ssl=bool(section.get("verify_ssl", True)),
        )
    raise ValueError(
        f"Unknown azure_devops mode {mode!r}. Expected 'rest' or 'local'."
    )
