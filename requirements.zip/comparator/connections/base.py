"""Shared contracts for connections."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class ConnectionError_(Exception):
    """Raised when a backend cannot be reached or authenticated."""


class Connection(ABC):
    """Base class for every external system the comparator talks to."""

    name: str = "connection"

    @abstractmethod
    def check(self) -> Dict[str, Any]:
        """Verify connectivity. Returns a small dict of diagnostic details.

        Raises ConnectionError_ when the backend is unusable.
        """


class RepoConnection(Connection):
    """A source of text files identified by repo-relative path and ref.

    A ref is a branch in REST mode. Single-ref backends (a plain local
    checkout) report one synthetic ref and ignore the argument, so callers
    can always pass one.
    """

    @property
    @abstractmethod
    def refs(self) -> List[str]:
        """Refs to search, in priority order. Never empty."""

    @abstractmethod
    def read_text(self, path: str, ref: Optional[str] = None) -> str:
        """Return the file's contents from `ref` (default: the first ref).

        Raises FileNotFoundError when the path does not exist on that ref.
        """

    @abstractmethod
    def describe(self, path: str, ref: Optional[str] = None) -> str:
        """Human-readable origin for the report (URL or absolute path)."""

    def exists(self, path: str, ref: Optional[str] = None) -> bool:
        try:
            self.read_text(path, ref)
            return True
        except FileNotFoundError:
            return False
