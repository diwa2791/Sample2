"""Configuration loading with ${ENV:default} interpolation."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::([^}]*))?\}")

# comparator/config.py -> project root -> config/config.yaml
DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "config.yaml"


def _interpolate(value: Any) -> Any:
    """Recursively replace ${VAR} / ${VAR:default} with environment values."""
    if isinstance(value, str):

        def repl(match: re.Match) -> str:
            name, default = match.group(1), match.group(2)
            return os.environ.get(name) or (default or "")

        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, dict):
        return {k: _interpolate(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_interpolate(v) for v in value]
    return value


class Config:
    """Dotted-path access over the parsed config tree."""

    def __init__(self, data: Dict[str, Any], path: Optional[Path] = None) -> None:
        self._data = data
        self.path = path

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "Config":
        cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
        if not cfg_path.is_file():
            raise FileNotFoundError(f"Config file not found: {cfg_path}")
        with cfg_path.open("r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        return cls(_interpolate(raw), cfg_path)

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self._data
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def section(self, dotted: str) -> Dict[str, Any]:
        value = self.get(dotted, {})
        return value if isinstance(value, dict) else {}

    def require(self, dotted: str) -> Any:
        value = self.get(dotted)
        if value in (None, ""):
            raise ValueError(f"Missing required config value: {dotted}")
        return value

    @property
    def services(self) -> List[str]:
        return list(self.get("target.services", []) or [])

    @property
    def data(self) -> Dict[str, Any]:
        return self._data
