"""Build snapshots from live Kubernetes state."""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from comparator.config import Config
from comparator.connections.base import ConnectionError_
from comparator.connections.kubernetes import KubernetesConnection
from comparator.models import ImageSpec, ResourceSpec, ServiceSnapshot, Side
from comparator.utils.yaml_utils import parse_properties

LOG = logging.getLogger(__name__)


class KubernetesSource:
    """Reads the running Deployment and its ConfigMap."""

    side = Side.RIGHT

    def __init__(self, connection: KubernetesConnection, config: Config) -> None:
        self.conn = connection
        self.cfg = config
        section = config.section("sources.kubernetes")
        self.configmap_tpl = section.get("configmap_name_template", "{service}-config")
        self.discover_configmap = bool(section.get("discover_configmap", True))
        self.props_key = config.get(
            "repo_layout.service_properties_key", "serviceProperties"
        )

    # -- configmap --------------------------------------------------------

    def _configmap_names(self, deployment: Any, service: str) -> List[str]:
        """ConfigMaps referenced by the pod spec, best first.

        Discovery beats convention: a deployment tells us exactly which
        ConfigMap it consumes, via volumes or envFrom.
        """
        names: List[str] = []
        if self.discover_configmap and deployment is not None:
            pod_spec = deployment.spec.template.spec
            for volume in pod_spec.volumes or []:
                if getattr(volume, "config_map", None):
                    names.append(volume.config_map.name)
            for container in pod_spec.containers or []:
                for env_from in getattr(container, "env_from", None) or []:
                    if getattr(env_from, "config_map_ref", None):
                        names.append(env_from.config_map_ref.name)
        fallback = self.configmap_tpl.format(service=service)
        if fallback not in names:
            names.append(fallback)
        # Preserve order, drop duplicates.
        return list(dict.fromkeys(names))

    def _config(self, deployment: Any, service: str) -> Tuple[Dict[str, str], List[str], Optional[str]]:
        issues: List[str] = []
        for name in self._configmap_names(deployment, service):
            try:
                cm = self.conn.get_configmap(name)
            except ConnectionError_ as exc:
                issues.append(str(exc))
                continue
            if cm is None:
                continue
            data = cm.data or {}
            # Preferred shape: one properties blob under serviceProperties.
            if self.props_key in data:
                return parse_properties(data[self.props_key]), issues, name
            # Otherwise treat each data key as a flat config entry.
            return {k: str(v) for k, v in data.items()}, issues, name
        issues.append(f"no configmap found for {service}")
        return {}, issues, None

    # -- public -----------------------------------------------------------

    def list_services(self) -> List[str]:
        """Every Deployment in the namespace."""
        try:
            return sorted(self.conn.list_deployment_names())
        except ConnectionError_ as exc:
            LOG.warning("Could not list deployments for discovery: %s", exc)
            return []

    def snapshot(self, service: str) -> ServiceSnapshot:
        snap = ServiceSnapshot(name=service, side=Side.RIGHT)

        try:
            deployment = self.conn.get_deployment(service)
        except ConnectionError_ as exc:
            snap.found = False
            snap.issues.append(str(exc))
            return snap

        if deployment is None:
            snap.found = False
            snap.issues.append(
                f"deployment {service!r} not found in namespace {self.conn.namespace!r}"
            )
            return snap

        snap.origin["deployment"] = f"{self.conn.namespace}/{service}"

        container = _pick_container(deployment, service)
        if container is None:
            snap.issues.append("deployment has no containers")
            return snap

        snap.image = _parse_image_ref(container.image or "")
        snap.resources = ResourceSpec(_resources_from_container(container, deployment))

        config, issues, cm_name = self._config(deployment, service)
        snap.config = config
        snap.issues.extend(issues)
        if cm_name:
            snap.origin["configmap"] = f"{self.conn.namespace}/{cm_name}"

        return snap


def _pick_container(deployment: Any, service: str) -> Optional[Any]:
    """Prefer the container named after the service; else the first one."""
    containers = deployment.spec.template.spec.containers or []
    for container in containers:
        if container.name == service:
            return container
    return containers[0] if containers else None


_IMAGE_RE = re.compile(
    r"^(?:(?P<registry>[^/]+\.[^/]+(?::\d+)?|localhost(?::\d+)?)/)?"
    r"(?P<path>.+?)"
    r"(?::(?P<tag>[^:@/]+))?"
    r"(?:@(?P<digest>sha256:[0-9a-f]+))?$"
)


def _parse_image_ref(ref: str) -> ImageSpec:
    """Split `registry/path:tag@sha256:...` into parts."""
    match = _IMAGE_RE.match(ref.strip())
    if not match:
        return ImageSpec(raw=ref or None)
    groups = match.groupdict()
    return ImageSpec(
        registry=groups.get("registry"),
        path=groups.get("path"),
        tag=groups.get("tag"),
        digest=groups.get("digest"),
    )


def _resources_from_container(container: Any, deployment: Any) -> Dict[str, Optional[str]]:
    resources = getattr(container, "resources", None)
    requests = (getattr(resources, "requests", None) or {}) if resources else {}
    limits = (getattr(resources, "limits", None) or {}) if resources else {}

    def as_str(value: Any) -> Optional[str]:
        return None if value is None else str(value)

    replicas = getattr(deployment.spec, "replicas", None)
    return {
        "requests.memory": as_str(requests.get("memory")),
        "requests.cpu": as_str(requests.get("cpu")),
        "limits.memory": as_str(limits.get("memory")),
        "limits.cpu": as_str(limits.get("cpu")),
        "replicaCount": as_str(replicas),
    }
