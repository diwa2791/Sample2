"""Tolerant YAML + properties parsing.

The helm values files in this repo are hand-maintained and not strictly valid
YAML: they mix tabs with spaces, write `replicaCount:1` with no space after the
colon, and hold `serviceProperties` as a free-form block that was never marked
as a YAML block scalar (`|-`).

Rather than fail the whole run on one bad file, we normalise what is safely
normalisable, extract the properties blocks by indentation before YAML ever
sees them, and surface whatever we had to repair as issues on the snapshot.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

import yaml

# key:value  ->  key: value      (only when no space already follows the colon)
_TIGHT_KEY = re.compile(r"^(\s*)([A-Za-z_][\w.\-]*)\s*:(\S.*)$")

# These files indent with real tabs at the conventional 8-column stop. Expanding
# at any other width lands nested keys *shallower* than their parent and YAML
# rejects the block, so this width is load-bearing -- do not change it to 4.
TABSTOP = 8


def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def extract_block(text: str, key: str) -> Tuple[str, Optional[str]]:
    """Pull a free-form block out of `text` by indentation.

    Finds a line `<indent><key>:` and captures every following line that is
    either blank or indented deeper than the key. Returns the text with the
    block removed and the block's raw contents (dedented), or None if absent.
    """
    lines = text.splitlines()
    start = None
    key_indent = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped in (f"{key}:", f"{key}: |", f"{key}: |-", f"{key}: |8-"):
            start = i
            key_indent = _indent_of(line.expandtabs(TABSTOP))
            break
    if start is None:
        return text, None

    body: List[str] = []
    end = len(lines)
    for j in range(start + 1, len(lines)):
        expanded = lines[j].expandtabs(TABSTOP)
        if not expanded.strip():
            body.append("")
            continue
        if _indent_of(expanded) <= key_indent:
            end = j
            break
        body.append(expanded)
    else:
        end = len(lines)

    # Dedent by the shallowest non-empty line so properties line up.
    non_empty = [b for b in body if b.strip()]
    shift = min((_indent_of(b) for b in non_empty), default=0)
    block = "\n".join(b[shift:] if b.strip() else "" for b in body).strip("\n")

    remaining = lines[:start] + lines[end:]
    return "\n".join(remaining), block


def normalise_yaml_text(text: str) -> Tuple[str, List[str]]:
    """Repair the common hand-editing mistakes. Returns (text, notes)."""
    notes: List[str] = []
    out: List[str] = []

    if "\t" in text:
        notes.append("tabs expanded to spaces")

    for raw in text.expandtabs(TABSTOP).splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            out.append(line)
            continue

        match = _TIGHT_KEY.match(line)
        if match:
            indent, key, value = match.groups()
            value = value.strip()
            # A value containing a colon must be quoted or YAML rejects it.
            if ":" in value and not (value[:1] in "\"'"):
                value = '"{}"'.format(value.replace('"', '\\"'))
            line = f"{indent}{key}: {value}"
            notes.append(f"added missing space after '{key}:'")
        out.append(line)

    return "\n".join(out), notes


def safe_load_lenient(text: str) -> Tuple[Dict[str, Any], List[str]]:
    """Parse YAML, repairing it first if a strict parse fails.

    Returns (data, issues). `data` is {} when the text is unparseable even
    after normalisation; the reason is then in `issues`.
    """
    issues: List[str] = []
    try:
        data = yaml.safe_load(text)
        if isinstance(data, dict):
            return data, issues
        if data is None:
            return {}, issues
        issues.append(f"expected a YAML mapping, got {type(data).__name__}")
        return {}, issues
    except yaml.YAMLError:
        pass  # fall through to repair

    repaired, notes = normalise_yaml_text(text)
    try:
        data = yaml.safe_load(repaired)
    except yaml.YAMLError as exc:
        issues.append(f"invalid YAML even after normalisation: {_brief(exc)}")
        return {}, issues

    if not isinstance(data, dict):
        issues.append("normalised YAML did not produce a mapping")
        return {}, issues

    issues.append(
        "YAML was not strictly valid and was auto-repaired ({})".format(
            ", ".join(sorted(set(notes))) or "whitespace fixes"
        )
    )
    return data, issues


def parse_properties(block: str) -> Dict[str, str]:
    """Parse a java .properties style block into a flat dict.

    Accepts both `k=v` and `k: v`, ignores blank lines and # comments.
    """
    result: Dict[str, str] = {}
    if not block:
        return result
    for raw in block.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
        elif ":" in line:
            key, _, value = line.partition(":")
        else:
            continue
        key = key.strip()
        if key:
            result[key] = value.strip()
    return result


def dig(data: Dict[str, Any], dotted: str, default: Any = None) -> Any:
    """Fetch a nested value by dotted path."""
    node: Any = data
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def _brief(exc: Exception) -> str:
    return " ".join(str(exc).split())[:160]
