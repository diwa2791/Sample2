package com.k8sdashboard.controller;

import com.k8sdashboard.model.*;
import com.k8sdashboard.service.MockDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/dev")
@RequiredArgsConstructor
public class DevController {

    private final MockDataService dataService;
    private static final String ENV = "DEV";

    // ── Pages ──────────────────────────────────────────────────

    @GetMapping
    public String devDashboard(
            @RequestParam(defaultValue = "running") String tab,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "") String search,
            Model model) {

        Map<String, Long> stats = dataService.getPodStats(ENV);
        List<Pod> pods = getFilteredPods(tab, search);

        // Pagination: 20 pods per page to keep DOM lean
        int pageSize = 20;
        int total = pods.size();
        int totalPages = (int) Math.ceil((double) total / pageSize);
        page = Math.max(0, Math.min(page, Math.max(0, totalPages - 1)));
        List<Pod> pagePods = pods.subList(
                Math.min(page * pageSize, total),
                Math.min((page + 1) * pageSize, total)
        );

        model.addAttribute("env", ENV);
        model.addAttribute("tab", tab);
        model.addAttribute("stats", stats);
        model.addAttribute("pods", pagePods);
        model.addAttribute("page", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("total", total);
        model.addAttribute("search", search);
        model.addAttribute("backups", dataService.getBackups(ENV));
        return "dev/index";
    }

    // ── REST: Scale ────────────────────────────────────────────

    @PostMapping("/api/pods/{podName}/scale")
    @ResponseBody
    public ApiResponse<Void> scalePod(
            @PathVariable String podName,
            @RequestParam int replicas) {
        if (replicas < 0 || replicas > 20) {
            return ApiResponse.error("Replicas must be between 0 and 20");
        }
        dataService.scaleDeployment(ENV, podName, replicas);
        return ApiResponse.ok("Scaled " + podName + " to " + replicas + " replicas");
    }

    // ── REST: ConfigMap ────────────────────────────────────────

    @GetMapping("/api/pods/{deploymentName}/configmap")
    @ResponseBody
    public ApiResponse<ConfigMap> getConfigMap(@PathVariable String deploymentName) {
        return ApiResponse.ok("OK", dataService.getConfigMap(ENV, deploymentName));
    }

    @PutMapping("/api/pods/{deploymentName}/configmap")
    @ResponseBody
    public ApiResponse<Void> updateConfigMap(
            @PathVariable String deploymentName,
            @RequestBody Map<String, String> data) {
        dataService.updateConfigMap(ENV, deploymentName, data);
        return ApiResponse.ok("ConfigMap updated for " + deploymentName);
    }

    // ── REST: Deployment ───────────────────────────────────────

    @GetMapping("/api/pods/{deploymentName}/deployment")
    @ResponseBody
    public ApiResponse<Deployment> getDeployment(@PathVariable String deploymentName) {
        return ApiResponse.ok("OK", dataService.getDeployment(ENV, deploymentName));
    }

    @PutMapping("/api/pods/{deploymentName}/deployment")
    @ResponseBody
    public ApiResponse<Void> updateDeployment(
            @PathVariable String deploymentName,
            @RequestBody Deployment deployment) {
        deployment.setName(deploymentName);
        dataService.updateDeployment(ENV, deploymentName, deployment);
        return ApiResponse.ok("Deployment updated for " + deploymentName);
    }

    // ── REST: Logs ─────────────────────────────────────────────

    @GetMapping("/api/pods/{podName}/logs")
    public ResponseEntity<byte[]> downloadLogs(
            @PathVariable String podName,
            @RequestParam(defaultValue = "200") int lines) {
        String logs = dataService.generateLogs(podName, Math.min(lines, 1000));
        byte[] bytes = logs.getBytes();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + podName + ".log\"")
                .contentType(MediaType.TEXT_PLAIN)
                .contentLength(bytes.length)
                .body(bytes);
    }

    @GetMapping("/api/pods/{podName}/logs/view")
    @ResponseBody
    public ApiResponse<String> viewLogs(
            @PathVariable String podName,
            @RequestParam(defaultValue = "100") int lines) {
        return ApiResponse.ok("OK", dataService.generateLogs(podName, Math.min(lines, 500)));
    }

    // ── REST: Backup ───────────────────────────────────────────

    @PostMapping("/api/backup")
    @ResponseBody
    public ApiResponse<Backup> createBackup() {
        Backup backup = dataService.createBackup(ENV);
        return ApiResponse.ok("Backup created: " + backup.getId(), backup);
    }

    @GetMapping("/api/backups")
    @ResponseBody
    public ApiResponse<List<Backup>> listBackups() {
        return ApiResponse.ok("OK", dataService.getBackups(ENV));
    }

    // ── Helpers ────────────────────────────────────────────────

    private List<Pod> getFilteredPods(String tab, String search) {
        String status = switch (tab) {
            case "failed" -> "FAILED";
            case "crashloop" -> "CRASH_LOOP";
            default -> "RUNNING";
        };
        List<Pod> pods = dataService.getPodsByStatus(ENV, status);
        if (search != null && !search.isBlank()) {
            String q = search.toLowerCase();
            pods = pods.stream()
                    .filter(p -> p.getName().toLowerCase().contains(q)
                            || p.getDeploymentName().toLowerCase().contains(q)
                            || p.getNamespace().toLowerCase().contains(q))
                    .toList();
        }
        return pods;
    }
}
