"""Comment-preserving edits to a YAML file.

config.yaml is documentation as much as configuration: it carries the comments
that explain every knob, and `${ENV:default}` placeholders that keep secrets
out of the file. A load/dump round-trip would wreck both -- PyYAML drops every
comment, and Config.load() resolves the placeholders, so dumping the loaded
tree back would bake in whatever the environment happened to hold at the time.

So nothing here round-trips. We locate the line a setting lives on and rewrite
only the value text after the colon; every other byte of the file, comments
included, is left exactly as it was.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterator, List, Optional, Tuple

import yaml

# A mapping key line: `  key: rest`. List items (`- x`) deliberately do not
# match -- they are handled as part of their parent key's block.
_KEY_RE = re.compile(r"^(?P<indent> *)(?P<key>[A-Za-z_][\w.\-]*)\s*:(?P<rest>.*)$")

# Characters that force a scalar to be quoted.
_NEEDS_QUOTE = re.compile(r"^\s|\s$|[:#\[\]{},&*!|>'\"%@`]|^$")


def iter_key_lines(lines: List[str]) -> Iterator[Tuple[int, int, str, str]]:
    """Yield (index, indent, dotted_path, rest_of_line) for every mapping key."""
    stack: List[Tuple[int, str]] = []
    for i, raw in enumerate(lines):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        match = _KEY_RE.match(raw)
        if not match:
            continue
        indent = len(match.group("indent"))
        while stack and stack[-1][0] >= indent:
            stack.pop()
        stack.append((indent, match.group("key")))
        yield i, indent, ".".join(k for _, k in stack), match.group("rest")


def find_key(lines: List[str], path: str) -> Optional[Tuple[int, int, str]]:
    """Locate a dotted path. Returns (index, indent, rest) or None."""
    for i, indent, found, rest in iter_key_lines(lines):
        if found == path:
            return i, indent, rest
    return None


def _split_comment(rest: str) -> Tuple[str, str]:
    """Separate a trailing ` # comment` from the value, respecting quotes."""
    in_quote = ""
    for i, ch in enumerate(rest):
        if in_quote:
            if ch == in_quote:
                in_quote = ""
        elif ch in "\"'":
            in_quote = ch
        elif ch == "#" and i > 0 and rest[i - 1] in " \t":
            return rest[:i].rstrip(), "  " + rest[i:].strip()
    return rest.strip(), ""


def format_scalar(value: Any) -> str:
    """Render a Python value as YAML scalar text."""
    if value is None:
        return '""'
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)

    text = str(value)
    # ${ENV:default} is safe bare and must stay readable -- quoting it would
    # work but makes the file uglier than it was.
    if text.startswith("${") and text.endswith("}") and '"' not in text:
        return text
    if _NEEDS_QUOTE.search(text):
        return '"{}"'.format(text.replace("\\", "\\\\").replace('"', '\\"'))
    return text


def _block_extent(lines: List[str], start: int, indent: int) -> int:
    """Index one past the child block belonging to the key at `start`.

    A child is any deeper-indented line, or a `- item` at the same indent
    (YAML allows a sequence to sit level with its key). Trailing blank lines
    and comments are left alone -- they usually belong to whatever comes next.
    """
    end = start + 1
    last_content = end
    for j in range(start + 1, len(lines)):
        line = lines[j]
        if not line.strip():
            end = j + 1
            continue
        stripped = line.lstrip()
        line_indent = len(line) - len(stripped)
        is_seq_at_key_indent = line_indent == indent and stripped.startswith("- ")
        if line_indent > indent or is_seq_at_key_indent:
            if stripped.startswith("#"):
                # A comment inside the block: keep scanning, but do not treat
                # it as content we are willing to delete past.
                end = j + 1
                continue
            end = j + 1
            last_content = end
            continue
        break
    return last_content


def set_scalar(lines: List[str], path: str, value: Any) -> bool:
    found = find_key(lines, path)
    if not found:
        return False
    i, indent, rest = found
    _, comment = _split_comment(rest)
    key = _KEY_RE.match(lines[i]).group("key")
    # Drop any block that used to hang off this key (it becomes a scalar).
    end = _block_extent(lines, i, indent)
    lines[i:end] = ["{}{}: {}{}".format(" " * indent, key, format_scalar(value), comment)]
    return True


def set_list(lines: List[str], path: str, items: List[str]) -> bool:
    found = find_key(lines, path)
    if not found:
        return False
    i, indent, rest = found
    _, comment = _split_comment(rest)
    key = _KEY_RE.match(lines[i]).group("key")
    end = _block_extent(lines, i, indent)
    if not items:
        block = ["{}{}: []{}".format(" " * indent, key, comment)]
    else:
        block = ["{}{}:{}".format(" " * indent, key, comment)]
        block += ["{}- {}".format(" " * (indent + 2), format_scalar(x)) for x in items]
    lines[i:end] = block
    return True


def set_map(lines: List[str], path: str, mapping: Dict[str, str]) -> bool:
    found = find_key(lines, path)
    if not found:
        return False
    i, indent, rest = found
    _, comment = _split_comment(rest)
    key = _KEY_RE.match(lines[i]).group("key")
    end = _block_extent(lines, i, indent)
    if not mapping:
        block = ["{}{}: {{}}{}".format(" " * indent, key, comment)]
    else:
        block = ["{}{}:{}".format(" " * indent, key, comment)]
        block += [
            "{}{}: {}".format(" " * (indent + 2), k, format_scalar(v))
            for k, v in mapping.items()
        ]
    lines[i:end] = block
    return True


def apply_changes(text: str, changes: List[Tuple[str, str, Any]]) -> str:
    """Apply [(kind, path, value), ...] to YAML text.

    kind is 'scalar' | 'list' | 'map'. Raises KeyError for a path that is not
    in the file -- silently inventing keys would put settings somewhere the
    reader would never look.
    """
    lines = text.splitlines()
    setters = {"scalar": set_scalar, "list": set_list, "map": set_map}
    for kind, path, value in changes:
        setter = setters.get(kind)
        if setter is None:
            raise ValueError(f"Unknown field kind: {kind!r}")
        if not setter(lines, path, value):
            raise KeyError(f"{path} is not present in the config file")
    return "\n".join(lines) + "\n"


def load_raw(text: str) -> Dict[str, Any]:
    """Parse without ${ENV} interpolation -- the file as written, not as resolved."""
    data = yaml.safe_load(text)
    return data if isinstance(data, dict) else {}


def dig_raw(data: Dict[str, Any], dotted: str, default: Any = None) -> Any:
    node: Any = data
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node
