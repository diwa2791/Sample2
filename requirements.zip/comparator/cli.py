"""Argument parsing and command wiring.

This is not the entry point -- run `main.py` in the project root, which
delegates here:

    python main.py check                  # verify both connections
    python main.py                        # Kube2Branch -> HTML report
    python main.py folders --left sit --right prd    # Folder2Folder
    python main.py ui                     # web hub (both, plus config)
    python main.py --drift-only           # hide matching keys
    python main.py list-comparators       # show registered utilities
"""

from __future__ import annotations

import argparse
import logging
import sys
import webbrowser
from pathlib import Path
from typing import List, Optional

from comparator.comparison.registry import available
from comparator.config import Config
from comparator.connections.azure_devops import build_repo_connection
from comparator.connections.base import ConnectionError_
from comparator.connections.kubernetes import KubernetesConnection
from comparator.report.html import HtmlReportRenderer
from comparator.runner import (
    RunError,
    run_build2build,
    run_folder2folder,
    run_kube2branch,
)

LOG = logging.getLogger("comparator")


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)-7s %(message)s",
    )


def _load(args: argparse.Namespace) -> Config:
    cfg = Config.load(Path(args.config) if args.config else None)
    # CLI overrides win over file/env so one-off runs need no edits.
    if getattr(args, "namespace", None):
        cfg.data["connections"]["kubernetes"]["namespace"] = args.namespace
    if getattr(args, "ado_mode", None):
        cfg.data["connections"]["azure_devops"]["mode"] = args.ado_mode
    if getattr(args, "branches", None):
        cfg.data["connections"]["azure_devops"]["branches"] = args.branches
    return cfg


def cmd_check(args: argparse.Namespace) -> int:
    cfg = _load(args)
    failed = False

    try:
        details = build_repo_connection(cfg).check()
        print(f"[ok]   azure devops: {details}")
    except (ConnectionError_, ValueError) as exc:
        print(f"[fail] azure devops: {exc}")
        failed = True

    try:
        details = KubernetesConnection.from_config(cfg).check()
        print(f"[ok]   kubernetes:   {details}")
    except (ConnectionError_, ValueError) as exc:
        print(f"[fail] kubernetes:   {exc}")
        failed = True

    return 1 if failed else 0


def cmd_compare(args: argparse.Namespace) -> int:
    cfg = _load(args)
    try:
        report = run_kube2branch(cfg, services=args.services)
    except RunError as exc:
        LOG.error("%s", exc)
        return 2
    out = HtmlReportRenderer(cfg).write(
        report, args.output, show_matches=not args.drift_only
    )
    _print_summary(report, out, args.open)
    return _exit_code(cfg, report)


def cmd_folders(args: argparse.Namespace) -> int:
    """Compare the same chart across two environment folders (e.g. sit vs prd)."""
    cfg = _load(args)
    try:
        report = run_folder2folder(
            cfg,
            left_env=args.left,
            right_env=args.right,
            cluster=args.cluster,
            services=args.services,
        )
    except RunError as exc:
        LOG.error("%s", exc)
        return 2
    out = HtmlReportRenderer(cfg).write(
        report, args.output, show_matches=not args.drift_only
    )
    _print_summary(report, out, args.open)
    return _exit_code(cfg, report)


def cmd_builds(args: argparse.Namespace) -> int:
    """Compare the chart at the commits behind two CD pipeline runs."""
    cfg = _load(args)
    try:
        report = run_build2build(
            cfg,
            old_url=args.old,
            new_url=args.new,
            cluster=args.cluster,
            env=args.env,
            services=args.services,
        )
    except RunError as exc:
        LOG.error("%s", exc)
        return 2
    out = HtmlReportRenderer(cfg).write(
        report, args.output, show_matches=not args.drift_only
    )
    _print_summary(report, out, args.open)
    return _exit_code(cfg, report)


def _print_summary(report, out: Path, open_it: bool) -> None:
    print()
    for svc in report.services:
        marker = "DRIFT" if svc.has_drift else "  ok "
        where = f" [{svc.branch}]" if svc.branch else ""
        print(
            f"[{marker}] {svc.name}{where}: "
            f"{svc.drift_count} difference(s), {len(svc.issues)} issue(s)"
        )
    print(f"\nReport: {out}")
    if open_it:
        webbrowser.open(out.as_uri())


def _exit_code(cfg: Config, report) -> int:
    if cfg.get("report.fail_on_mismatch", False) and report.total_drift:
        LOG.warning("Drift detected and report.fail_on_mismatch is set.")
        return 1
    return 0


def cmd_ui(args: argparse.Namespace) -> int:
    """Serve the local hub: Kube2Branch, Folder2Folder and the config editor."""
    from comparator.config import DEFAULT_CONFIG_PATH
    from comparator.webui.server import serve

    path = Path(args.config) if args.config else DEFAULT_CONFIG_PATH
    if not path.is_file():
        LOG.error("Config file not found: %s", path)
        return 2
    serve(
        path,
        port=args.port,
        open_browser=not args.no_open,
        landing=getattr(args, "landing", "/kube2branch"),
    )
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    cfg = _load(args)
    enabled = cfg.section("comparison.enabled")
    print("Registered comparators:")
    for name in available():
        state = "enabled" if enabled.get(name) else "disabled"
        print(f"  {name:<12} {state}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="comparator",
        description="Compare declared Azure DevOps helm values against live Kubernetes state.",
    )
    parser.add_argument("-c", "--config", help="Path to config.yaml")
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)

    check = sub.add_parser("check", help="Verify connectivity to both backends")
    check.add_argument("--ado-mode", choices=["rest", "local"])
    check.add_argument("--branches", nargs="+", help="Override the branches to search")
    check.add_argument("-n", "--namespace")
    check.set_defaults(func=cmd_check)

    compare = sub.add_parser("compare", help="Run the comparison and write the report")
    compare.add_argument("--services", nargs="+", help="Override target.services")
    compare.add_argument("-o", "--output", help="Override report.output_path")
    compare.add_argument("--ado-mode", choices=["rest", "local"])
    compare.add_argument("--branches", nargs="+", help="Override the branches to search")
    compare.add_argument("-n", "--namespace")
    compare.add_argument("--drift-only", action="store_true", help="Hide matching keys")
    compare.add_argument("--open", action="store_true", help="Open the report when done")
    compare.set_defaults(func=cmd_compare)

    folders = sub.add_parser(
        "folders", help="Compare two env folders of the chart (e.g. sit vs prd)"
    )
    folders.add_argument("--left", required=True, help="Left env folder, e.g. sit")
    folders.add_argument("--right", required=True, help="Right env folder, e.g. prd")
    folders.add_argument("--cluster", help="Override target.cluster")
    folders.add_argument("--services", nargs="+", help="Narrow to these services")
    folders.add_argument("-o", "--output", help="Override report.output_path")
    folders.add_argument("--ado-mode", choices=["rest", "local"])
    folders.add_argument("--branches", nargs="+")
    folders.add_argument("--drift-only", action="store_true")
    folders.add_argument("--open", action="store_true")
    folders.set_defaults(func=cmd_folders)

    builds = sub.add_parser(
        "builds", help="Compare the chart behind two CD pipeline runs (old vs new)"
    )
    builds.add_argument("--old", required=True, metavar="URL", help="Old pipeline run URL")
    builds.add_argument("--new", required=True, metavar="URL", help="New pipeline run URL")
    builds.add_argument("--cluster", help="Override target.cluster")
    builds.add_argument("--env", help="Override target.env")
    builds.add_argument("--services", nargs="+", help="Narrow to these services")
    builds.add_argument("-o", "--output", help="Override report.output_path")
    builds.add_argument("--drift-only", action="store_true")
    builds.add_argument("--open", action="store_true")
    builds.set_defaults(func=cmd_builds)

    listing = sub.add_parser("list-comparators", help="Show registered comparators")
    listing.set_defaults(func=cmd_list)

    ui = sub.add_parser(
        "ui", help="Serve the local hub: Kube2Branch, Folder2Folder and Config"
    )
    ui.add_argument("-p", "--port", type=int, default=8765)
    ui.add_argument("--no-open", action="store_true", help="Do not open a browser")
    ui.set_defaults(func=cmd_ui, landing="/kube2branch")

    # `config` predates the hub and stays as an alias, landing on that page.
    conf = sub.add_parser("config", help="Open the hub on the config editor")
    conf.add_argument("-p", "--port", type=int, default=8765)
    conf.add_argument("--no-open", action="store_true", help="Do not open a browser")
    conf.set_defaults(func=cmd_ui, landing="/config")

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    _setup_logging(args.verbose)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        LOG.exception("Unexpected failure: %s", exc)
        return 2


if __name__ == "__main__":
    sys.exit(main())
